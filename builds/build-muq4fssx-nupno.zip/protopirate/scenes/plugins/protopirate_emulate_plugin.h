#pragma once

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include <gui/scene_manager.h>

#define PROTOPIRATE_EMULATE_PLUGIN_APP_ID      "pp_emulate"
#define PROTOPIRATE_EMULATE_PLUGIN_API_VERSION 2U

typedef struct {
    bool (*radio_init)(void* app);
    bool (*apply_protocol_registry_for_context)(
        void* app,
        const char* preset_name,
        uint32_t frequency,
        const uint8_t* preset_data,
        size_t preset_data_size,
        const char* protocol_name);
    void (*rx_stack_suspend_for_tx)(void* app);
    bool (*ensure_view_about)(void* app);
    bool (*ensure_text_input)(void* app);
    void (*idle)(void* app);
    void (*history_release_scratch)(void* app);
    void (*storage_delete_temp)(void);
} ProtoPirateEmulateHostApi;

typedef struct {
    const char* plugin_name;
    void (*set_host_api)(const ProtoPirateEmulateHostApi* host_api);
    void (*on_enter)(void* app);
    bool (*on_event)(void* app, SceneManagerEvent event);
    void (*on_exit)(void* app);
    void (*context_release)(void* app);
} ProtoPirateEmulatePlugin;
