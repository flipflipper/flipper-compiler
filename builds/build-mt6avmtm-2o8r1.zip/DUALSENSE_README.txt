DualSense Scanner patch for Flipper Zero Official 1.4.3
============================================================

WHAT THIS DOES
- Adds two small exported HAL calls: furi_hal_bt_scan_start/stop.
- Builds a real EXTERNAL .fap in applications_user/dualsense_scanner.
- Uses passive BLE advertisements only. It does NOT decrypt or intercept
  the PS5 <-> DualSense connection.
- The first version recognizes the advertised local name "Wireless Controller".
  Pairing mode (PS + Create) is the easiest way to make the controller advertise.

IMPORTANT ABOUT THE ZIP YOU UPLOADED
The GitHub source ZIP does not contain git submodule contents. In particular,
lib/stm32wb_cmsis is empty, so a full firmware build cannot be verified from that
archive alone. Use a recursive git clone for the actual build:

  git clone --recursive https://github.com/flipperdevices/flipperzero-firmware.git
  cd flipperzero-firmware
  git checkout 1.4.3
  git submodule update --init --recursive

Then apply DUALSENSE_1.4.3.patch from this package, OR copy the modified files
from the overlay directory.

BUILD
  ./fbt updater_package COMPACT=1 DEBUG=0

Windows:
  .\fbt.cmd updater_package COMPACT=1 DEBUG=0

The included fbt_options_local.py selects BLE Full.

After installing the custom update, build the FAP:
  ./fbt fap_dualsense_scanner

Expected FAP location is under build/f7-firmware-D/.extapps/ (exact build folder
name can vary).

INSTALL
Copy dualsense_scanner.fap to:
  /ext/apps/Tools/

RADIO WARNING
This changes the STM32WB coprocessor radio stack from BLE Light to BLE Full.
Use only the matching 1.20.0 radio binary from the official 1.4.3 submodule.
Do not flash random radio binaries.

LIMITATION
A controller already connected to the PS5 may not keep sending a useful
advertisement. This scanner can reliably tell you only what is actually being
advertised over BLE; it cannot prove that a particular DualSense is connected
to a particular PS5.
