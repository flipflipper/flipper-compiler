#include <furi.h>
#include <furi_hal_bt.h>
#include <gui/gui.h>
#include <gui/view_port.h>
#include <input/input.h>
#include <notification/notification_messages.h>

typedef struct {
    FuriMessageQueue* queue;
    FuriMutex* mutex;
    ViewPort* viewport;
    NotificationApp* notifications;
    bool scan_ok;
    bool found;
    bool alerted;
    int8_t rssi;
    uint8_t addr[6];
    char name[24];
} App;

static void parse_name(const uint8_t* data, uint8_t len, char* out, size_t cap) {
    out[0] = 0;
    uint8_t p = 0;
    while(p < len) {
        uint8_t n = data[p];
        if(!n || (uint16_t)p + n >= (uint16_t)len + 1) break;
        if(n >= 2 && (data[p + 1] == 0x08 || data[p + 1] == 0x09)) {
            size_t copy = n - 1;
            if(copy >= cap) copy = cap - 1;
            memcpy(out, data + p + 2, copy);
            out[copy] = 0;
            return;
        }
        p += n + 1;
    }
}

static bool contains(const char* s, const char* q) {
    if(!s || !q) return false;
    size_t sl = strlen(s), ql = strlen(q);
    if(ql > sl) return false;
    for(size_t i = 0; i <= sl - ql; i++) {
        if(memcmp(s + i, q, ql) == 0) return true;
    }
    return false;
}

static void scan_cb(
    const uint8_t address[6],
    uint8_t address_type,
    int8_t rssi,
    const uint8_t* data,
    uint8_t data_len,
    void* context) {
    UNUSED(address_type);
    App* app = context;

    char name[24];
    parse_name(data, data_len, name, sizeof(name));

    furi_mutex_acquire(app->mutex, FuriWaitForever);
    memcpy(app->addr, address, 6);
    app->rssi = rssi;
    strlcpy(app->name, name[0] ? name : "(sans nom)", sizeof(app->name));

    /* Learn mode: many DualSense advertise this local name while pairing. */
    app->found = contains(app->name, "Wireless Controller");

    if(app->found && !app->alerted) {
        app->alerted = true;
        notification_message(app->notifications, &sequence_success);
    } else if(!app->found) {
        app->alerted = false;
    }
    furi_mutex_release(app->mutex);

    view_port_update(app->viewport);
}

static void draw(Canvas* canvas, void* context) {
    App* app = context;
    furi_mutex_acquire(app->mutex, FuriWaitForever);

    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 2, 11, "DualSense Scanner");
    canvas_set_font(canvas, FontSecondary);

    if(!app->scan_ok) {
        canvas_draw_str(canvas, 2, 29, "BLE Full requis");
        canvas_draw_str(canvas, 2, 43, "Scan impossible");
        canvas_draw_str(canvas, 2, 62, "BACK: quitter");
    } else {
        char line[32];
        snprintf(line, sizeof(line), "%02X:%02X:%02X:%02X:%02X:%02X",
            app->addr[0], app->addr[1], app->addr[2],
            app->addr[3], app->addr[4], app->addr[5]);
        canvas_draw_str(canvas, 2, 24, line);

        snprintf(line, sizeof(line), "RSSI: %d dBm", app->rssi);
        canvas_draw_str(canvas, 2, 36, line);
        canvas_draw_str(canvas, 2, 48, app->name);

        if(app->found) {
            canvas_set_font(canvas, FontPrimary);
            canvas_draw_str(canvas, 2, 62, "MANETTE TROUVEE!");
        } else {
            canvas_draw_str(canvas, 2, 62, "PS+Create / BACK");
        }
    }

    furi_mutex_release(app->mutex);
}

static void input_cb(InputEvent* event, void* context) {
    App* app = context;
    furi_message_queue_put(app->queue, event, 0);
}

int32_t dualsense_scanner_app(void* p) {
    UNUSED(p);

    App app = {0};
    app.rssi = -127;
    app.queue = furi_message_queue_alloc(8, sizeof(InputEvent));
    app.mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    app.viewport = view_port_alloc();
    app.notifications = furi_record_open(RECORD_NOTIFICATION);

    view_port_draw_callback_set(app.viewport, draw, &app);
    view_port_input_callback_set(app.viewport, input_cb, &app);

    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, app.viewport, GuiLayerFullscreen);

    app.scan_ok = furi_hal_bt_scan_start(scan_cb, &app);
    view_port_update(app.viewport);

    bool run = true;
    while(run) {
        InputEvent event;
        if(furi_message_queue_get(app.queue, &event, 250) == FuriStatusOk) {
            if(event.type == InputTypeShort && event.key == InputKeyBack) run = false;
        }
    }

    if(app.scan_ok) furi_hal_bt_scan_stop();

    gui_remove_view_port(gui, app.viewport);
    view_port_free(app.viewport);
    furi_record_close(RECORD_GUI);
    furi_record_close(RECORD_NOTIFICATION);
    furi_mutex_free(app.mutex);
    furi_message_queue_free(app.queue);
    return 0;
}
