# DualSense scanner build: use STM32WB BLE Full stack.
COPRO_OB_DATA = "scripts/ob_custradio.data"
COPRO_STACK_BIN = "stm32wb5x_BLE_Stack_full_fw.bin"
COPRO_STACK_TYPE = "ble_full"
