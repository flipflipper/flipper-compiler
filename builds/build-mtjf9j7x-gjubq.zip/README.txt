EMF METER V1 - Momentum
=======================

Fonctions
---------
- Écran de démarrage avec "LIVIO GRECO"
- Jauge d'intensité 0-100%
- Peak Hold
- LEDs selon l'intensité
- Vibration sur forte intensité
- OK = remet le peak à la valeur courante
- BACK = quitter

IMPORTANT
---------
Cette version est un indicateur RELATIF de type EMF, pas un appareil de mesure
calibré en microteslas (uT) ou milligauss (mG).

Le Flipper Zero n'intègre pas un véritable magnétomètre/EMF meter large bande.
Pour une mesure physique réelle et calibrable, il faut ajouter un capteur externe
(GPIO/I2C/ADC), par exemple un module magnétomètre adapté. L'application peut
ensuite être modifiée pour lire ce capteur et afficher une vraie intensité.
