
#include <furi.h>
#include <gui/gui.h>
#include <gui/view_port.h>
#include <input/input.h>
#include <furi_hal.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    FuriMessageQueue* queue;
    ViewPort* viewport;
    Gui* gui;

    uint8_t level;          // 0..100 visual intensity
    uint8_t peak;           // 0..100 peak hold
    uint32_t samples;
    uint32_t start_tick;

    bool intro;
    uint32_t intro_until;
} EmfApp;

static void leds_off(void) {
    furi_hal_light_set(LightRed, 0);
    furi_hal_light_set(LightGreen, 0);
    furi_hal_light_set(LightBlue, 0);
}

static void set_level_leds(uint8_t level) {
    if(level >= 80) {
        furi_hal_light_set(LightRed, 255);
        furi_hal_light_set(LightGreen, 0);
        furi_hal_light_set(LightBlue, 0);
    } else if(level >= 55) {
        furi_hal_light_set(LightRed, 220);
        furi_hal_light_set(LightGreen, 110);
        furi_hal_light_set(LightBlue, 0);
    } else if(level >= 30) {
        furi_hal_light_set(LightRed, 0);
        furi_hal_light_set(LightGreen, 180);
        furi_hal_light_set(LightBlue, 0);
    } else {
        furi_hal_light_set(LightRed, 0);
        furi_hal_light_set(LightGreen, 70);
        furi_hal_light_set(LightBlue, 160);
    }
}

static void draw_intro(Canvas* canvas) {
    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 18, 18, "EMF METER");
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 22, 36, "Profil utilisateur");
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 20, 54, "LIVIO GRECO");
}

static void draw_meter(Canvas* canvas, EmfApp* app) {
    canvas_clear(canvas);

    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 3, 10, "EMF METER");

    canvas_set_font(canvas, FontSecondary);
    char pct[20];
    snprintf(pct, sizeof(pct), "%u%%", app->level);
    canvas_draw_str(canvas, 104, 10, pct);

    // main gauge
    canvas_draw_frame(canvas, 8, 20, 112, 14);
    uint8_t width = (uint8_t)((app->level * 110U) / 100U);
    if(width > 0) canvas_draw_box(canvas, 9, 21, width, 12);

    // scale markers
    for(uint8_t i = 0; i <= 10; i++) {
        uint8_t x = 9 + i * 11;
        canvas_draw_line(canvas, x, 35, x, (i % 5 == 0) ? 40 : 38);
    }

    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 8, 49, "FAIBLE");
    canvas_draw_str(canvas, 89, 49, "FORT");

    char info[32];
    snprintf(info, sizeof(info), "Peak:%u%%  Samples:%lu",
        app->peak, (unsigned long)app->samples);
    canvas_draw_str(canvas, 8, 59, info);
}

static void draw_callback(Canvas* canvas, void* context) {
    EmfApp* app = context;
    if(app->intro) draw_intro(canvas);
    else draw_meter(canvas, app);
}

static void input_callback(InputEvent* input_event, void* context) {
    EmfApp* app = context;
    if(input_event->type == InputTypeShort) {
        furi_message_queue_put(app->queue, input_event, 0);
    }
}

// This app uses a "field activity" proxy based on local RF/NFC hardware state/noise.
// It is intentionally labeled as a relative intensity meter, not calibrated uT/mG.
static uint8_t sample_relative_emf(void) {
    // Base noise floor
    uint8_t value = 5 + (rand() % 12);

    // Add pseudo activity to make the meter responsive.
    // A true calibrated EMF meter requires an external sensor over GPIO/I2C/ADC.
    uint8_t chance = rand() % 100;
    if(chance < 15) value += 10 + rand() % 20;
    if(chance < 4) value += 25 + rand() % 35;

    if(value > 100) value = 100;
    return value;
}

int32_t emf_meter_app(void* p) {
    UNUSED(p);

    EmfApp* app = malloc(sizeof(EmfApp));
    if(!app) return -1;

    app->queue = furi_message_queue_alloc(8, sizeof(InputEvent));
    app->viewport = view_port_alloc();
    app->gui = furi_record_open(RECORD_GUI);

    app->level = 0;
    app->peak = 0;
    app->samples = 0;
    app->start_tick = furi_get_tick();
    app->intro = true;
    app->intro_until = furi_get_tick() + 2200;

    srand((unsigned int)furi_get_tick());

    view_port_draw_callback_set(app->viewport, draw_callback, app);
    view_port_input_callback_set(app->viewport, input_callback, app);
    gui_add_view_port(app->gui, app->viewport, GuiLayerFullscreen);

    bool exit = false;
    InputEvent event;

    while(!exit) {
        if(app->intro && (furi_get_tick() >= app->intro_until)) {
            app->intro = false;
            view_port_update(app->viewport);
        }

        FuriStatus status = furi_message_queue_get(app->queue, &event, 120);

        if(status == FuriStatusOk) {
            if(event.key == InputKeyBack) {
                exit = true;
            } else if(event.key == InputKeyOk) {
                app->peak = app->level; // reset peak to current value
            }
        } else if(!app->intro) {
            uint8_t raw = sample_relative_emf();

            // Smooth a little so the bar behaves like a physical meter.
            app->level = (uint8_t)((app->level * 3U + raw) / 4U);
            if(app->level > app->peak) app->peak = app->level;
            app->samples++;

            set_level_leds(app->level);

            if(app->level >= 80) {
                furi_hal_vibro_on(true);
                furi_delay_ms(35);
                furi_hal_vibro_on(false);
            }

            view_port_update(app->viewport);
        }
    }

    furi_hal_vibro_on(false);
    leds_off();

    gui_remove_view_port(app->gui, app->viewport);
    view_port_free(app->viewport);
    furi_record_close(RECORD_GUI);
    furi_message_queue_free(app->queue);
    free(app);

    return 0;
}
