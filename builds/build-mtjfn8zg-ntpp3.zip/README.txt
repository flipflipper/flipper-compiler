SPIRIT BOX V4 - MOMENTUM

Cette version pousse le buzzer interne du Flipper aussi loin que raisonnablement possible:
- bruit synthétique mis à jour rapidement (hiss/crackle/chirps)
- pseudo 'voice hits' à plusieurs bandes de fréquences
- volume 0-10
- sweep 87.5-108.0 MHz
- 50/75/100/125/150/200/250/300 ms
- FWD / REV
- compteur SW
- jauge signal
- LEDs + vibration

Commandes:
OK = marche/pause
HAUT/BAS = volume
HAUT long = volume 10
BAS long = muet
GAUCHE = FWD/REV
DROITE = vitesse
BACK = quitter

NOTE IMPORTANTE:
Le Flipper Zero ne possède pas de récepteur FM 87.5-108 MHz et son transducteur interne
est un buzzer, pas un haut-parleur PCM. Les fréquences affichées, parasites et 'voice hits'
sont donc une simulation sonore/visuelle, et non des stations ou voix réellement reçues.
