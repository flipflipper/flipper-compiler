
#include <furi.h>
#include <gui/gui.h>
#include <gui/view_port.h>
#include <input/input.h>
#include <furi_hal.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    FuriMessageQueue* queue;
    ViewPort* viewport;
    Gui* gui;
    bool running, reverse, speaker_owned;
    uint32_t frequency_khz, sweeps, speed_ms, last_audio_tick;
    uint8_t volume, signal, audio_phase, hit_ticks;
    bool voice_hit;
} SpiritBoxApp;

static float volume_float(uint8_t v) {
    if(v == 0) return 0.0f;
    return 0.035f + ((float)v / 10.0f) * 0.60f;
}

static void lights_off(void) {
    furi_hal_light_set(LightRed,0);
    furi_hal_light_set(LightGreen,0);
    furi_hal_light_set(LightBlue,0);
}

static void update_lights(SpiritBoxApp* a) {
    if(a->voice_hit) {
        furi_hal_light_set(LightRed,255);
        furi_hal_light_set(LightGreen,0);
        furi_hal_light_set(LightBlue,180);
    } else if(a->signal > 75) {
        furi_hal_light_set(LightRed,255);
        furi_hal_light_set(LightGreen,35);
        furi_hal_light_set(LightBlue,0);
    } else if(a->signal > 42) {
        furi_hal_light_set(LightRed,130);
        furi_hal_light_set(LightGreen,150);
        furi_hal_light_set(LightBlue,0);
    } else {
        furi_hal_light_set(LightRed,0);
        furi_hal_light_set(LightGreen,60);
        furi_hal_light_set(LightBlue,180);
    }
}

/*
 * The internal Flipper speaker is a piezo buzzer, not a PCM loudspeaker.
 * This routine layers rapidly changing frequencies, chirps and warbles to
 * create the richest "radio sweep/static" illusion available from it.
 */
static void audio_frame(SpiritBoxApp* a) {
    if(!a->speaker_owned) return;
    if(!a->running || a->volume == 0) {
        furi_hal_speaker_stop();
        return;
    }

    float vol = volume_float(a->volume);
    uint32_t r = rand();

    if(a->voice_hit) {
        // Formant-like alternating warble: pseudo syllabic texture.
        static const float voice_bands[] = {310, 430, 570, 720, 910, 1180, 1450};
        uint8_t idx = (a->audio_phase + (r % 3)) % 7;
        float f = voice_bands[idx];
        if(a->audio_phase & 1) f *= 1.12f;
        furi_hal_speaker_start(f, vol);
    } else {
        // Multi-character static: hiss-like highs, crackle mids and scan chirps.
        uint8_t mode = r % 10;
        float f;
        float gain = vol;

        if(mode < 5) {
            f = 2800.0f + (float)(r % 4300);      // hiss texture
            gain *= 0.35f + ((float)a->signal / 180.0f);
        } else if(mode < 8) {
            f = 900.0f + (float)(r % 2200);       // crackle/body
            gain *= 0.55f;
        } else {
            f = 1250.0f + (float)((a->frequency_khz % 2500) / 2);
            gain *= 0.75f;                        // sweep chirp
        }

        if(gain > vol) gain = vol;
        furi_hal_speaker_start(f, gain);
    }

    a->audio_phase++;
}

static void draw_cb(Canvas* c, void* ctx) {
    SpiritBoxApp* a = ctx;
    canvas_clear(c);

    canvas_set_font(c, FontPrimary);
    canvas_draw_str(c, 2, 10, "SBX SPIRIT BOX");
    canvas_set_font(c, FontSecondary);
    canvas_draw_str(c, 99, 10, a->running ? "RUN" : "STOP");

    char buf[32];
    snprintf(buf,sizeof(buf),"%lu.%01lu",
        (unsigned long)(a->frequency_khz/1000),
        (unsigned long)((a->frequency_khz%1000)/100));
    canvas_set_font(c, FontBigNumbers);
    canvas_draw_str(c, 5, 31, buf);
    canvas_set_font(c, FontSecondary);
    canvas_draw_str(c, 95, 29, "MHz");

    snprintf(buf,sizeof(buf),"%s %lums  SW:%lu",
        a->reverse ? "REV" : "FWD",
        (unsigned long)a->speed_ms,
        (unsigned long)a->sweeps);
    canvas_draw_str(c,3,42,buf);

    canvas_draw_str(c,3,52,"SIG");
    canvas_draw_frame(c,24,46,64,8);
    uint8_t w=(uint8_t)((a->signal*62U)/100U);
    if(w) canvas_draw_box(c,25,47,w,6);

    snprintf(buf,sizeof(buf),"VOL:%u",a->volume);
    canvas_draw_str(c,94,52,buf);

    if(a->voice_hit) {
        canvas_set_font(c,FontPrimary);
        canvas_draw_str(c,31,63,"VOICE HIT");
    } else {
        canvas_set_font(c,FontSecondary);
        canvas_draw_str(c,2,63,"OK run U/D vol L dir R speed");
    }
}

static void input_cb(InputEvent* e, void* ctx) {
    SpiritBoxApp* a=ctx;
    if(e->type==InputTypeShort || e->type==InputTypeLong)
        furi_message_queue_put(a->queue,e,0);
}

static void cycle_speed(SpiritBoxApp* a) {
    const uint32_t speeds[] = {50,75,100,125,150,200,250,300};
    for(size_t i=0;i<8;i++) {
        if(a->speed_ms==speeds[i]) {
            a->speed_ms=speeds[(i+1)%8];
            return;
        }
    }
    a->speed_ms=100;
}

static void sweep_step(SpiritBoxApp* a) {
    if(a->reverse) {
        if(a->frequency_khz<=87500) { a->frequency_khz=108000; a->sweeps++; }
        else a->frequency_khz-=100;
    } else {
        if(a->frequency_khz>=108000) { a->frequency_khz=87500; a->sweeps++; }
        else a->frequency_khz+=100;
    }

    uint8_t r=rand()%100;
    if(r<66) a->signal=8+rand()%35;
    else if(r<93) a->signal=43+rand()%30;
    else a->signal=73+rand()%28;

    if(!a->voice_hit && (rand()%100)<6) {
        a->voice_hit=true;
        a->hit_ticks=2+rand()%5;
        furi_hal_vibro_on(true);
    } else if(a->voice_hit) {
        if(a->hit_ticks) a->hit_ticks--;
        if(!a->hit_ticks) {
            a->voice_hit=false;
            furi_hal_vibro_on(false);
        }
    }
    update_lights(a);
}

int32_t spiritbox_app(void* p) {
    UNUSED(p);
    SpiritBoxApp* a=malloc(sizeof(SpiritBoxApp));
    if(!a) return -1;

    a->queue=furi_message_queue_alloc(8,sizeof(InputEvent));
    a->viewport=view_port_alloc();
    a->gui=furi_record_open(RECORD_GUI);
    a->running=true; a->reverse=false; a->speaker_owned=false;
    a->frequency_khz=87500; a->sweeps=0; a->speed_ms=100;
    a->last_audio_tick=0; a->volume=6; a->signal=20;
    a->audio_phase=0; a->hit_ticks=0; a->voice_hit=false;

    srand((unsigned int)furi_get_tick());
    view_port_draw_callback_set(a->viewport,draw_cb,a);
    view_port_input_callback_set(a->viewport,input_cb,a);
    gui_add_view_port(a->gui,a->viewport,GuiLayerFullscreen);
    a->speaker_owned=furi_hal_speaker_acquire(1000);

    bool exit=false;
    InputEvent e;
    uint32_t last_sweep=furi_get_tick();

    while(!exit) {
        FuriStatus st=furi_message_queue_get(a->queue,&e,18);
        if(st==FuriStatusOk) {
            if(e.type==InputTypeShort) {
                if(e.key==InputKeyBack) exit=true;
                else if(e.key==InputKeyOk) {
                    a->running=!a->running;
                    if(!a->running) {
                        furi_hal_vibro_on(false);
                        lights_off();
                        if(a->speaker_owned) furi_hal_speaker_stop();
                    }
                } else if(e.key==InputKeyUp && a->volume<10) a->volume++;
                else if(e.key==InputKeyDown && a->volume>0) a->volume--;
                else if(e.key==InputKeyLeft) a->reverse=!a->reverse;
                else if(e.key==InputKeyRight) cycle_speed(a);
            } else if(e.type==InputTypeLong) {
                if(e.key==InputKeyUp) a->volume=10;
                else if(e.key==InputKeyDown) a->volume=0;
            }
            view_port_update(a->viewport);
        }

        if(a->running) {
            uint32_t now=furi_get_tick();
            if(now-last_sweep>=a->speed_ms) {
                last_sweep=now;
                sweep_step(a);
                view_port_update(a->viewport);
            }
            // Audio updates much faster than the displayed sweep for denser texture.
            if(now-a->last_audio_tick>=18) {
                a->last_audio_tick=now;
                audio_frame(a);
            }
        }
    }

    furi_hal_vibro_on(false);
    lights_off();
    if(a->speaker_owned) {
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }
    gui_remove_view_port(a->gui,a->viewport);
    view_port_free(a->viewport);
    furi_record_close(RECORD_GUI);
    furi_message_queue_free(a->queue);
    free(a);
    return 0;
}
