#include "protopirate_views.h"
#include "../protopirate_app_i.h"

#include <furi.h>

#define TAG "PPViews"

bool protopirate_ensure_widget(ProtoPirateApp* app) {
    if(app->widget) {
        return true;
    }

    app->widget = widget_alloc();
    if(!app->widget) {
        return false;
    }

    view_dispatcher_add_view(
        app->view_dispatcher, ProtoPirateViewWidget, widget_get_view(app->widget));
    return true;
}

bool protopirate_ensure_text_input(ProtoPirateApp* app) {
    if(app->text_input) {
        return true;
    }

    FURI_LOG_D(TAG, "Adding text input view");
    app->text_input = text_input_alloc();
    if(!app->text_input) {
        return false;
    }

    view_dispatcher_add_view(
        app->view_dispatcher, ProtoPirateViewTextInput, text_input_get_view(app->text_input));
    FURI_LOG_D(TAG, "Added text input view");
    return true;
}

void protopirate_free_text_input(ProtoPirateApp* app) {
    if(app->text_input) {
        FURI_LOG_D(TAG, "Removing text_input view");
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewTextInput);
        text_input_free(app->text_input);
        app->text_input = NULL;
    }

    if(app->save_filename) {
        free(app->save_filename);
        app->save_filename = NULL;
    }
}

bool protopirate_ensure_view_about(ProtoPirateApp* app) {
    if(app->view_about) {
        return true;
    }

    app->view_about = view_alloc();
    if(!app->view_about) {
        return false;
    }

    view_dispatcher_add_view(app->view_dispatcher, ProtoPirateViewAbout, app->view_about);
    return true;
}

bool protopirate_ensure_receiver_view(ProtoPirateApp* app) {
    if(app->protopirate_receiver) {
        return true;
    }

    app->protopirate_receiver = protopirate_view_receiver_alloc(app->auto_save);
    if(!app->protopirate_receiver) {
        return false;
    }

    view_dispatcher_add_view(
        app->view_dispatcher,
        ProtoPirateViewReceiver,
        protopirate_view_receiver_get_view(app->protopirate_receiver));
    return true;
}

void protopirate_views_free(ProtoPirateApp* app) {
    if(app->submenu) {
        FURI_LOG_D(TAG, "Removing submenu view");
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewSubmenu);
        submenu_free(app->submenu);
        app->submenu = NULL;
    }

    if(app->variable_item_list) {
        FURI_LOG_D(TAG, "Removing variable_item_list view");
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewVariableItemList);
        app->variable_item_list = NULL;
    }

    if(app->view_about) {
        FURI_LOG_D(TAG, "Removing about view");
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewAbout);
        view_free(app->view_about);
        app->view_about = NULL;
    }

    if(app->widget) {
        FURI_LOG_D(TAG, "Removing widget view");
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewWidget);
        widget_free(app->widget);
        app->widget = NULL;
    }

    if(app->text_input) {
        FURI_LOG_D(TAG, "Removing text_input view");
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewTextInput);
        text_input_free(app->text_input);
        app->text_input = NULL;
    }

    if(app->protopirate_receiver) {
        FURI_LOG_D(TAG, "Removing receiver view");
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewReceiver);
        protopirate_view_receiver_free(app->protopirate_receiver);
        app->protopirate_receiver = NULL;
    }
}

void protopirate_variable_item_list_free(ProtoPirateApp* app) {
    if(app->variable_item_list) {
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewVariableItemList);
        variable_item_list_free(app->variable_item_list);
        app->variable_item_list = NULL;
    }
}

void protopirate_widget_free(ProtoPirateApp* app) {
    if(app->widget) {
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewWidget);
        widget_free(app->widget);
        app->widget = NULL;
    }
}
