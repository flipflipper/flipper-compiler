
#include <furi.h>
#include <gui/gui.h>
#include <gui/view_port.h>
#include <input/input.h>
#include <furi_hal.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

typedef enum {
    ModeMenu = 0,
    ModeSpirit,
    ModeEmf,
    ModeRem,
    ModeRadar,
    ModeRf
} AppMode;

typedef struct {
    FuriMessageQueue* queue;
    ViewPort* viewport;
    Gui* gui;

    AppMode mode;
    uint8_t menu_index;

    bool speaker_owned;
    uint8_t volume;

    // Shared/session
    uint32_t tick;
    uint32_t events;

    // Spirit Box
    bool spirit_running;
    bool spirit_reverse;
    uint32_t spirit_freq_khz;
    uint32_t spirit_speed_ms;
    uint32_t spirit_sweeps;
    uint8_t spirit_signal;
    bool spirit_hit;
    uint8_t spirit_hit_ticks;
    uint32_t last_spirit_step;
    uint32_t last_audio_tick;

    // EMF / REM / RF simulated relative levels
    uint8_t emf_level;
    uint8_t emf_peak;
    uint8_t rem_level;
    uint8_t rf_level;

    // Radar
    uint8_t radar_x[5];
    uint8_t radar_y[5];
    uint8_t radar_strength[5];
    uint8_t radar_count;
    uint32_t last_radar_spawn;

    bool intro;
    uint32_t intro_until;
} Toolkit;

static float volf(uint8_t v) {
    if(v == 0) return 0.0f;
    return 0.04f + ((float)v / 10.0f) * 0.58f;
}

static void lights_off(void) {
    furi_hal_light_set(LightRed,0);
    furi_hal_light_set(LightGreen,0);
    furi_hal_light_set(LightBlue,0);
}

static void set_level_lights(uint8_t l) {
    if(l >= 80) {
        furi_hal_light_set(LightRed,255);
        furi_hal_light_set(LightGreen,0);
        furi_hal_light_set(LightBlue,0);
    } else if(l >= 55) {
        furi_hal_light_set(LightRed,230);
        furi_hal_light_set(LightGreen,110);
        furi_hal_light_set(LightBlue,0);
    } else if(l >= 30) {
        furi_hal_light_set(LightRed,0);
        furi_hal_light_set(LightGreen,190);
        furi_hal_light_set(LightBlue,0);
    } else {
        furi_hal_light_set(LightRed,0);
        furi_hal_light_set(LightGreen,55);
        furi_hal_light_set(LightBlue,170);
    }
}

static void beep(Toolkit* a, float freq, uint32_t ms, float scale) {
    if(!a->speaker_owned || a->volume == 0) return;
    float v = volf(a->volume) * scale;
    if(v > 1.0f) v = 1.0f;
    furi_hal_speaker_start(freq, v);
    furi_delay_ms(ms);
    furi_hal_speaker_stop();
}

static void draw_intro(Canvas* c) {
    canvas_clear(c);
    canvas_set_font(c, FontSecondary);
    canvas_draw_str(c, 33, 11, "PARANORMAL");
    canvas_draw_frame(c, 7, 16, 114, 45);
    canvas_set_font(c, FontPrimary);
    canvas_draw_str(c, 26, 36, "LIVIO GRECO");
    canvas_set_font(c, FontSecondary);
    canvas_draw_str(c, 22, 53, "INVESTIGATION KIT");
}

static void draw_bar(Canvas* c, uint8_t x, uint8_t y, uint8_t w, uint8_t level) {
    canvas_draw_frame(c, x, y, w, 10);
    uint8_t fill = (uint8_t)(((w - 2) * (uint16_t)level) / 100U);
    if(fill) canvas_draw_box(c, x + 1, y + 1, fill, 8);
}

static void draw_menu(Canvas* c, Toolkit* a) {
    static const char* items[] = {
        "Spirit Box",
        "EMF Meter",
        "REM Pod",
        "Ghost Radar",
        "RF Detector"
    };

    canvas_clear(c);
    canvas_set_font(c, FontPrimary);
    canvas_draw_str(c, 2, 10, "LIVIO PARANORMAL");

    canvas_set_font(c, FontSecondary);
    for(uint8_t i=0; i<5; i++) {
        uint8_t y = 22 + i*9;
        if(i == a->menu_index) {
            canvas_draw_box(c, 2, y-7, 124, 9);
            canvas_set_color(c, ColorWhite);
            canvas_draw_str(c, 7, y, items[i]);
            canvas_set_color(c, ColorBlack);
        } else {
            canvas_draw_str(c, 7, y, items[i]);
        }
    }
}

static void draw_spirit(Canvas* c, Toolkit* a) {
    canvas_clear(c);
    canvas_set_font(c,FontPrimary);
    canvas_draw_str(c,2,10,"SPIRIT BOX");

    char b[32];
    snprintf(b,sizeof(b),"%lu.%01lu",
        (unsigned long)(a->spirit_freq_khz/1000),
        (unsigned long)((a->spirit_freq_khz%1000)/100));
    canvas_set_font(c,FontBigNumbers);
    canvas_draw_str(c,7,31,b);
    canvas_set_font(c,FontSecondary);
    canvas_draw_str(c,95,29,"MHz");

    snprintf(b,sizeof(b),"%s %lums SW:%lu",
        a->spirit_reverse ? "REV" : "FWD",
        (unsigned long)a->spirit_speed_ms,
        (unsigned long)a->spirit_sweeps);
    canvas_draw_str(c,3,42,b);

    canvas_draw_str(c,3,52,"SIG");
    draw_bar(c,24,45,64,a->spirit_signal);

    snprintf(b,sizeof(b),"V%u",a->volume);
    canvas_draw_str(c,102,52,b);

    if(a->spirit_hit) {
        canvas_set_font(c,FontPrimary);
        canvas_draw_str(c,30,63,"VOICE HIT");
    } else {
        canvas_set_font(c,FontSecondary);
        canvas_draw_str(c,2,63,"OK run U/D vol L dir R speed");
    }
}

static void draw_emf(Canvas* c, Toolkit* a) {
    canvas_clear(c);
    canvas_set_font(c,FontPrimary);
    canvas_draw_str(c,2,10,"EMF METER");
    draw_bar(c,8,20,112,a->emf_level);

    canvas_set_font(c,FontSecondary);
    char b[32];
    snprintf(b,sizeof(b),"LEVEL %u%%",a->emf_level);
    canvas_draw_str(c,8,44,b);
    snprintf(b,sizeof(b),"PEAK %u%%",a->emf_peak);
    canvas_draw_str(c,8,55,b);
    snprintf(b,sizeof(b),"VOL %u",a->volume);
    canvas_draw_str(c,91,55,b);
    canvas_draw_str(c,8,64,"OK reset peak");
}

static void draw_rem(Canvas* c, Toolkit* a) {
    canvas_clear(c);
    canvas_set_font(c,FontPrimary);
    canvas_draw_str(c,2,10,"REM POD");
    canvas_set_font(c,FontSecondary);
    canvas_draw_str(c,2,21,"PROXIMITY / FIELD");

    draw_bar(c,8,28,112,a->rem_level);
    char b[32];
    snprintf(b,sizeof(b),"INTENSITY %u%%",a->rem_level);
    canvas_draw_str(c,8,52,b);

    if(a->rem_level >= 75) {
        canvas_set_font(c,FontPrimary);
        canvas_draw_str(c,34,64,"ALERT");
    } else {
        canvas_set_font(c,FontSecondary);
        canvas_draw_str(c,2,64,"Move around to test");
    }
}

static void draw_radar(Canvas* c, Toolkit* a) {
    canvas_clear(c);
    canvas_set_font(c,FontPrimary);
    canvas_draw_str(c,2,10,"GHOST RADAR");

    uint8_t cx=64, cy=38;
    canvas_draw_circle(c,cx,cy,24);
    canvas_draw_circle(c,cx,cy,16);
    canvas_draw_circle(c,cx,cy,8);
    canvas_draw_line(c,cx-26,cy,cx+26,cy);
    canvas_draw_line(c,cx,cy-26,cx,cy+26);

    for(uint8_t i=0;i<a->radar_count;i++) {
        uint8_t x=a->radar_x[i], y=a->radar_y[i];
        if(a->radar_strength[i] > 70) canvas_draw_disc(c,x,y,3);
        else canvas_draw_disc(c,x,y,2);
    }

    canvas_set_font(c,FontSecondary);
    char b[24];
    snprintf(b,sizeof(b),"ANOMALIES:%u",a->radar_count);
    canvas_draw_str(c,2,63,b);
}

static void draw_rf(Canvas* c, Toolkit* a) {
    canvas_clear(c);
    canvas_set_font(c,FontPrimary);
    canvas_draw_str(c,2,10,"RF DETECTOR");
    canvas_set_font(c,FontSecondary);
    canvas_draw_str(c,2,21,"RELATIVE ACTIVITY");

    draw_bar(c,8,28,112,a->rf_level);

    char b[32];
    snprintf(b,sizeof(b),"ACTIVITY %u%%",a->rf_level);
    canvas_draw_str(c,8,52,b);
    canvas_draw_str(c,8,63,"Relative/demo mode");
}

static void draw_cb(Canvas* c, void* ctx) {
    Toolkit* a=ctx;
    if(a->intro) {
        draw_intro(c);
        return;
    }

    switch(a->mode) {
        case ModeMenu: draw_menu(c,a); break;
        case ModeSpirit: draw_spirit(c,a); break;
        case ModeEmf: draw_emf(c,a); break;
        case ModeRem: draw_rem(c,a); break;
        case ModeRadar: draw_radar(c,a); break;
        case ModeRf: draw_rf(c,a); break;
    }
}

static void input_cb(InputEvent* e, void* ctx) {
    Toolkit* a=ctx;
    if(e->type==InputTypeShort || e->type==InputTypeLong)
        furi_message_queue_put(a->queue,e,0);
}

static uint8_t relative_sample(uint8_t bias) {
    uint8_t v = bias + (rand()%15);
    uint8_t r = rand()%100;
    if(r < 18) v += 10 + rand()%20;
    if(r < 5) v += 25 + rand()%35;
    if(v>100) v=100;
    return v;
}

static void cycle_spirit_speed(Toolkit* a) {
    const uint32_t speeds[] = {50,75,100,125,150,200,250,300};
    for(size_t i=0;i<8;i++) {
        if(a->spirit_speed_ms == speeds[i]) {
            a->spirit_speed_ms = speeds[(i+1)%8];
            return;
        }
    }
    a->spirit_speed_ms = 100;
}

static void spirit_audio(Toolkit* a) {
    if(!a->speaker_owned || !a->spirit_running || a->volume == 0) return;
    float v=volf(a->volume);
    uint32_t r=rand();

    if(a->spirit_hit) {
        static const float bands[]={320,430,570,720,910,1180,1450};
        float f=bands[r%7];
        furi_hal_speaker_start(f,v);
    } else {
        uint8_t mode=r%10;
        float f;
        float gain=v;
        if(mode<5) {
            f=2800.0f+(float)(r%4300);
            gain*=0.35f+((float)a->spirit_signal/180.0f);
        } else if(mode<8) {
            f=900.0f+(float)(r%2200);
            gain*=0.55f;
        } else {
            f=1250.0f+(float)((a->spirit_freq_khz%2500)/2);
            gain*=0.75f;
        }
        furi_hal_speaker_start(f,gain);
    }
}

static void spirit_step(Toolkit* a) {
    if(a->spirit_reverse) {
        if(a->spirit_freq_khz<=87500) {
            a->spirit_freq_khz=108000;
            a->spirit_sweeps++;
        } else a->spirit_freq_khz-=100;
    } else {
        if(a->spirit_freq_khz>=108000) {
            a->spirit_freq_khz=87500;
            a->spirit_sweeps++;
        } else a->spirit_freq_khz+=100;
    }

    uint8_t r=rand()%100;
    if(r<66) a->spirit_signal=8+rand()%35;
    else if(r<93) a->spirit_signal=43+rand()%30;
    else a->spirit_signal=73+rand()%28;

    if(!a->spirit_hit && (rand()%100)<6) {
        a->spirit_hit=true;
        a->spirit_hit_ticks=2+rand()%5;
        a->events++;
        furi_hal_vibro_on(true);
    } else if(a->spirit_hit) {
        if(a->spirit_hit_ticks) a->spirit_hit_ticks--;
        if(!a->spirit_hit_ticks) {
            a->spirit_hit=false;
            furi_hal_vibro_on(false);
        }
    }

    set_level_lights(a->spirit_signal);
}

static void update_modes(Toolkit* a) {
    if(a->mode==ModeEmf) {
        uint8_t raw=relative_sample(5);
        a->emf_level=(a->emf_level*3U+raw)/4U;
        if(a->emf_level>a->emf_peak) a->emf_peak=a->emf_level;
        set_level_lights(a->emf_level);
        if(a->emf_level>=70) beep(a,700.0f+a->emf_level*12.0f,20,0.8f);
    } else if(a->mode==ModeRem) {
        uint8_t raw=relative_sample(8);
        a->rem_level=(a->rem_level*3U+raw)/4U;
        set_level_lights(a->rem_level);
        if(a->rem_level>=75) {
            beep(a,1200.0f+a->rem_level*8.0f,35,0.9f);
            if((rand()%5)==0) {
                furi_hal_vibro_on(true);
                furi_delay_ms(25);
                furi_hal_vibro_on(false);
            }
        }
    } else if(a->mode==ModeRf) {
        uint8_t raw=relative_sample(10);
        a->rf_level=(a->rf_level*2U+raw)/3U;
        set_level_lights(a->rf_level);
        if(a->rf_level>=65) beep(a,900.0f+a->rf_level*10.0f,18,0.7f);
    }
}

static void radar_tick(Toolkit* a) {
    if(a->mode != ModeRadar) return;
    uint32_t now=furi_get_tick();
    if(now-a->last_radar_spawn < 900) return;
    a->last_radar_spawn=now;

    if((rand()%100)<45) {
        if(a->radar_count < 5) {
            uint8_t i=a->radar_count++;
            int dx=(rand()%43)-21;
            int dy=(rand()%43)-21;
            a->radar_x[i]=64+dx;
            a->radar_y[i]=38+dy;
            a->radar_strength[i]=30+rand()%71;
            a->events++;
            beep(a,500.0f+a->radar_strength[i]*8.0f,22,0.7f);
        } else {
            uint8_t i=rand()%5;
            int dx=(rand()%43)-21;
            int dy=(rand()%43)-21;
            a->radar_x[i]=64+dx;
            a->radar_y[i]=38+dy;
            a->radar_strength[i]=30+rand()%71;
        }
    } else if(a->radar_count>0 && (rand()%100)<20) {
        a->radar_count--;
    }
}

int32_t paranormal_toolkit_app(void* p) {
    UNUSED(p);
    Toolkit* a=malloc(sizeof(Toolkit));
    if(!a) return -1;

    a->queue=furi_message_queue_alloc(8,sizeof(InputEvent));
    a->viewport=view_port_alloc();
    a->gui=furi_record_open(RECORD_GUI);

    a->mode=ModeMenu;
    a->menu_index=0;
    a->speaker_owned=false;
    a->volume=6;
    a->tick=0;
    a->events=0;

    a->spirit_running=true;
    a->spirit_reverse=false;
    a->spirit_freq_khz=87500;
    a->spirit_speed_ms=100;
    a->spirit_sweeps=0;
    a->spirit_signal=20;
    a->spirit_hit=false;
    a->spirit_hit_ticks=0;
    a->last_spirit_step=furi_get_tick();
    a->last_audio_tick=0;

    a->emf_level=10;
    a->emf_peak=10;
    a->rem_level=8;
    a->rf_level=10;
    a->radar_count=0;
    a->last_radar_spawn=0;

    a->intro=true;
    a->intro_until=furi_get_tick()+2200;

    srand((unsigned int)furi_get_tick());

    view_port_draw_callback_set(a->viewport,draw_cb,a);
    view_port_input_callback_set(a->viewport,input_cb,a);
    gui_add_view_port(a->gui,a->viewport,GuiLayerFullscreen);

    a->speaker_owned=furi_hal_speaker_acquire(1000);

    bool exit=false;
    InputEvent e;

    while(!exit) {
        uint32_t now=furi_get_tick();

        if(a->intro && now>=a->intro_until) {
            a->intro=false;
            view_port_update(a->viewport);
        }

        FuriStatus st=furi_message_queue_get(a->queue,&e,30);

        if(st==FuriStatusOk && !a->intro) {
            if(e.type==InputTypeShort) {
                if(e.key==InputKeyBack) {
                    if(a->mode==ModeMenu) exit=true;
                    else {
                        a->mode=ModeMenu;
                        furi_hal_vibro_on(false);
                        lights_off();
                        if(a->speaker_owned) furi_hal_speaker_stop();
                    }
                } else if(a->mode==ModeMenu) {
                    if(e.key==InputKeyUp && a->menu_index>0) a->menu_index--;
                    else if(e.key==InputKeyDown && a->menu_index<4) a->menu_index++;
                    else if(e.key==InputKeyOk) a->mode=(AppMode)(a->menu_index+1);
                } else {
                    if(e.key==InputKeyUp && a->volume<10) a->volume++;
                    else if(e.key==InputKeyDown && a->volume>0) a->volume--;
                    else if(a->mode==ModeSpirit) {
                        if(e.key==InputKeyOk) {
                            a->spirit_running=!a->spirit_running;
                            if(!a->spirit_running && a->speaker_owned) furi_hal_speaker_stop();
                        } else if(e.key==InputKeyLeft) {
                            a->spirit_reverse=!a->spirit_reverse;
                        } else if(e.key==InputKeyRight) {
                            cycle_spirit_speed(a);
                        }
                    } else if(a->mode==ModeEmf && e.key==InputKeyOk) {
                        a->emf_peak=a->emf_level;
                    }
                }
            } else if(e.type==InputTypeLong && a->mode!=ModeMenu) {
                if(e.key==InputKeyUp) a->volume=10;
                else if(e.key==InputKeyDown) a->volume=0;
            }
            view_port_update(a->viewport);
        }

        if(a->intro) continue;

        now=furi_get_tick();

        if(a->mode==ModeSpirit && a->spirit_running) {
            if(now-a->last_spirit_step>=a->spirit_speed_ms) {
                a->last_spirit_step=now;
                spirit_step(a);
                view_port_update(a->viewport);
            }
            if(now-a->last_audio_tick>=18) {
                a->last_audio_tick=now;
                spirit_audio(a);
            }
        } else {
            if(a->speaker_owned) furi_hal_speaker_stop();
        }

        if((now-a->tick)>=120) {
            a->tick=now;
            update_modes(a);
            radar_tick(a);
            if(a->mode!=ModeSpirit) view_port_update(a->viewport);
        }
    }

    furi_hal_vibro_on(false);
    lights_off();
    if(a->speaker_owned) {
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }

    gui_remove_view_port(a->gui,a->viewport);
    view_port_free(a->viewport);
    furi_record_close(RECORD_GUI);
    furi_message_queue_free(a->queue);
    free(a);
    return 0;
}
