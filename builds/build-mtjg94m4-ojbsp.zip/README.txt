LIVIO PARANORMAL TOOLKIT - MOMENTUM

Modes:
1. Spirit Box
   - Sweep 87.5-108.0 MHz (simulated)
   - FWD/REV
   - 50-300 ms
   - synthetic static + voice hits
   - signal bar, LEDs, vibration, volume

2. EMF Meter
   - relative 0-100% gauge
   - peak hold
   - reactive beeps + LEDs
   - OK resets peak

3. REM Pod
   - proximity/field-style relative gauge
   - alert beeps + vibration

4. Ghost Radar
   - animated anomalies around center
   - event beeps

5. RF Detector
   - relative/demo RF-style activity gauge
   - reactive LEDs and beeps

Startup:
- Custom LIVIO GRECO intro

Controls:
- Menu: UP/DOWN select, OK open, BACK quit
- Inside tools: BACK returns to menu
- UP/DOWN = volume
- Long UP = max volume
- Long DOWN = mute
- Spirit Box: OK run/pause, LEFT direction, RIGHT speed

IMPORTANT:
- Spirit Box FM display is simulated. Flipper Zero does not receive commercial FM 87.5-108 MHz.
- EMF/REM/RF meters in this build are relative/demo indicators and not calibrated scientific sensors.
- Ghost Radar anomalies are simulated entertainment.
- For real physical EMF/magnetic measurements, connect an external sensor over GPIO/I2C and adapt the sampling routine.
