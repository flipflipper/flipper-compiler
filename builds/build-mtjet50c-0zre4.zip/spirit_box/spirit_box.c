// Spirit Box pour Flipper Zero (firmware Momentum)
// -----------------------------------------------------------------------
// Application recreative : balaie une liste de frequences sub-GHz avec le
// module radio du Flipper, lit le RSSI a chaque frequence, et affiche un
// mot aleatoire ("mot capte") lorsque le niveau de signal depasse un seuil
// ou de temps en temps de maniere aleatoire (comme les "spirit box" du
// commerce). En parallele :
//   - le haut-parleur (buzzer PWM) reproduit un grésillement statique en
//     continu, avec des "blips" qui changent de tonalite pendant les hits
//     (le Flipper n'a pas de DAC audio : il ne peut PAS jouer de vraie
//     voix/echantillon, seulement des tons synthetises - c'est la meilleure
//     approximation sonore possible sur ce materiel) ;
//   - la LED RGB reagit en direct : couleur qui varie selon la force du
//     signal (RSSI) pendant le balayage, flash blanc/rouge pendant un hit.
//
// Ce n'est PAS un instrument scientifique : un gadget ludique pour
// soirees/investigations "paranormales".
//
// Commandes :
//   OK    -> force un "hit" (affiche un mot) / reprend si en pause
//   LEFT  -> pause / reprise du balayage (coupe le son et la LED)
//   UP    -> accelere le balayage
//   DOWN  -> ralentit le balayage
//   BACK  -> quitter
// -----------------------------------------------------------------------

#include <furi.h>
#include <furi_hal.h>
#include <furi_hal_subghz.h>
#include <furi_hal_speaker.h>
#include <furi_hal_light.h>
#include <gui/gui.h>
#include <input/input.h>
#include <notification/notification.h>
#include <notification/notification_messages.h>
#include <stdlib.h>
#include <string.h>

#define TICK_MS 30
#define WORD_DISPLAY_TICKS (900 / TICK_MS)
#define RSSI_HIT_THRESHOLD -75.0f
#define NOISE_MIN_FREQ 200.0f
#define NOISE_MAX_FREQ 3200.0f
#define NOISE_VOLUME 0.25f
#define HIT_VOLUME 0.5f

// Banque de mots courts, style "reponses" de spirit box.
static const char* const word_bank[] = {
    "OUI",   "NON",    "SALUT",  "AIDE",   "PARTS", "ICI",   "REGARDE",
    "ECOUTE","FROID",  "SOMBRE", "NOM",    "QUI",   "POURQUOI", "STOP",
    "COURS", "DERRIERE", "ATTENDS", "BIENTOT", "PRES", "AMI", "SEUL",
    "TEMPS", "PORTE",  "LUMIERE","VOIS",   "SENS",  "SAIS", "VIENS", "VA",
};
#define WORD_COUNT (sizeof(word_bank) / sizeof(word_bank[0]))

// Table de frequences sub-GHz (Hz) couramment utilisees/autorisees selon
// les regions. Adapte cette liste a ta reglementation locale si besoin.
static const uint32_t freq_table[] = {
    300000000, 302757000, 303875000, 304250000, 307000000, 307500000,
    309000000, 310000000, 312000000, 312100000, 313000000, 313850000,
    314350000, 314980000, 315000000, 318000000, 330000000, 345000000,
    390000000, 418000000, 433075000, 433220000, 433420000, 433920000,
    434075000, 434176000, 434390000, 434420000, 434620000, 438900000,
    440175000, 464000000, 467750000, 779000000, 868350000, 868400000,
    868800000, 868950000, 906400000, 915000000, 925000000,
};
#define FREQ_COUNT (sizeof(freq_table) / sizeof(freq_table[0]))

typedef enum {
    SpiritBoxEventTick,
    SpiritBoxEventInput,
} SpiritBoxEventType;

typedef struct {
    SpiritBoxEventType type;
    InputEvent input;
} SpiritBoxEvent;

typedef struct {
    FuriMutex* mutex;
    FuriMessageQueue* queue;
    NotificationApp* notification;
    bool running;
    bool paused;
    bool radio_ok;
    bool speaker_ok;
    size_t freq_index;
    float rssi;
    char current_word[16];
    uint32_t word_ticks_left;
    uint32_t hit_count;
    uint32_t hop_delay_ms;
    uint32_t hop_accum;
} SpiritBoxState;

static void light_set_rgb(uint8_t r, uint8_t g, uint8_t b) {
    furi_hal_light_set(LightRed, r);
    furi_hal_light_set(LightGreen, g);
    furi_hal_light_set(LightBlue, b);
}

static void spirit_box_trigger_word(SpiritBoxState* s) {
    strncpy(s->current_word, word_bank[rand() % WORD_COUNT], sizeof(s->current_word) - 1);
    s->current_word[sizeof(s->current_word) - 1] = '\0';
    s->word_ticks_left = WORD_DISPLAY_TICKS;
    s->hit_count++;
    notification_message(s->notification, &sequence_single_vibro);
}

// Genere le "son" a chaque tick : grésillement statique aleatoire pendant
// le balayage normal, ou une alternance de deux tons pendant un hit (pour
// donner une impression de "voix" saccadee/robotique, sans etre une vraie
// synthese vocale que le materiel ne permet pas).
static void spirit_box_audio_tick(SpiritBoxState* s, uint32_t tick_counter) {
    if(!s->speaker_ok) return;

    if(s->word_ticks_left > 0) {
        float freq = (tick_counter % 2 == 0) ? 620.0f : 940.0f;
        furi_hal_speaker_start(freq, HIT_VOLUME);
    } else {
        float freq = NOISE_MIN_FREQ + (float)(rand() % (int)(NOISE_MAX_FREQ - NOISE_MIN_FREQ));
        float vol = NOISE_VOLUME * (0.5f + (float)(rand() % 50) / 100.0f);
        furi_hal_speaker_start(freq, vol);
    }
}

// Pilote la LED RGB en direct : couleur/intensite liee au RSSI pendant le
// balayage, flash blanc/rouge pendant un hit.
static void spirit_box_led_tick(SpiritBoxState* s) {
    if(s->word_ticks_left > 0) {
        // Flash façon "detection" : alterne blanc plein / rouge vif.
        bool flash_on = (s->word_ticks_left % 2) == 0;
        if(flash_on) {
            light_set_rgb(255, 255, 255);
        } else {
            light_set_rgb(255, 0, 0);
        }
        return;
    }

    // Normalise le RSSI (~ -100..-40 dBm) vers 0..255.
    float norm = (s->rssi + 100.0f) / 60.0f;
    if(norm < 0.0f) norm = 0.0f;
    if(norm > 1.0f) norm = 1.0f;
    uint8_t level = (uint8_t)(norm * 255.0f);

    // Bleu = fond de balayage, vert = force du signal.
    light_set_rgb(0, level, (uint8_t)(60 + (255 - 60) * (1.0f - norm)));
}

static void draw_callback(Canvas* canvas, void* ctx) {
    SpiritBoxState* s = ctx;
    furi_mutex_acquire(s->mutex, FuriWaitForever);

    canvas_clear(canvas);
    canvas_set_color(canvas, ColorBlack);

    // Bande de "bruit statique" en haut de l'ecran, purement decorative.
    for(int i = 0; i < 128; i += 2) {
        int h = (rand() % 6) + 1;
        canvas_draw_line(canvas, i, 12 - h, i, 12 + h);
    }

    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 2, 22, "SPIRIT BOX");

    canvas_set_font(canvas, FontSecondary);

    char freq_str[32];
    snprintf(
        freq_str,
        sizeof(freq_str),
        "%lu.%03lu MHz",
        (unsigned long)(freq_table[s->freq_index] / 1000000),
        (unsigned long)((freq_table[s->freq_index] / 1000) % 1000));
    canvas_draw_str(canvas, 2, 33, freq_str);

    char rssi_str[24];
    snprintf(
        rssi_str,
        sizeof(rssi_str),
        s->radio_ok ? "RSSI: %d dBm" : "SIMULATION",
        (int)s->rssi);
    canvas_draw_str(canvas, 2, 43, rssi_str);

    char hits_str[24];
    snprintf(hits_str, sizeof(hits_str), "Hits: %lu", (unsigned long)s->hit_count);
    canvas_draw_str(canvas, 82, 43, hits_str);

    if(s->word_ticks_left > 0) {
        canvas_draw_box(canvas, 4, 50, 120, 13);
        canvas_set_color(canvas, ColorWhite);
        canvas_set_font(canvas, FontPrimary);
        canvas_draw_str_aligned(canvas, 64, 57, AlignCenter, AlignCenter, s->current_word);
        canvas_set_color(canvas, ColorBlack);
    } else {
        canvas_draw_str(
            canvas, 2, 61, s->paused ? "PAUSE - OK pour reprendre" : "OK=forcer  Haut/Bas=vitesse");
    }

    furi_mutex_release(s->mutex);
}

static void input_callback(InputEvent* input_event, void* ctx) {
    FuriMessageQueue* queue = ctx;
    SpiritBoxEvent event = {.type = SpiritBoxEventInput, .input = *input_event};
    furi_message_queue_put(queue, &event, FuriWaitForever);
}

static void timer_callback(void* ctx) {
    FuriMessageQueue* queue = ctx;
    SpiritBoxEvent event = {.type = SpiritBoxEventTick};
    furi_message_queue_put(queue, &event, 0);
}

int32_t spirit_box_app(void* p) {
    UNUSED(p);

    SpiritBoxState* state = malloc(sizeof(SpiritBoxState));
    memset(state, 0, sizeof(SpiritBoxState));
    state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    state->queue = furi_message_queue_alloc(8, sizeof(SpiritBoxEvent));
    state->notification = furi_record_open(RECORD_NOTIFICATION);
    state->hop_delay_ms = 90;
    state->running = true;

    // Radio sub-GHz : si indisponible, bascule en mode simulation.
    state->radio_ok = furi_hal_subghz_is_frequency_valid(freq_table[0]);
    if(state->radio_ok) {
        furi_hal_subghz_reset();
        furi_hal_subghz_load_preset(FuriHalSubGhzPresetOok650Async);
        furi_hal_subghz_set_frequency_and_path(freq_table[0]);
        furi_hal_subghz_rx();
    }

    // Haut-parleur : on le reserve pour toute la duree de l'appli.
    state->speaker_ok = furi_hal_speaker_acquire(1000);

    ViewPort* view_port = view_port_alloc();
    view_port_draw_callback_set(view_port, draw_callback, state);
    view_port_input_callback_set(view_port, input_callback, state->queue);

    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, view_port, GuiLayerFullscreen);

    FuriTimer* timer = furi_timer_alloc(timer_callback, FuriTimerTypePeriodic, state->queue);
    furi_timer_start(timer, TICK_MS);

    uint32_t tick_counter = 0;
    SpiritBoxEvent event;

    while(state->running) {
        if(furi_message_queue_get(state->queue, &event, 100) == FuriStatusOk) {
            if(event.type == SpiritBoxEventInput) {
                if(event.input.type == InputTypeShort) {
                    furi_mutex_acquire(state->mutex, FuriWaitForever);
                    switch(event.input.key) {
                    case InputKeyBack:
                        state->running = false;
                        break;
                    case InputKeyOk:
                        if(state->paused) {
                            state->paused = false;
                        } else {
                            spirit_box_trigger_word(state);
                        }
                        break;
                    case InputKeyLeft:
                        state->paused = !state->paused;
                        if(state->paused) {
                            if(state->speaker_ok) furi_hal_speaker_stop();
                            light_set_rgb(0, 0, 0);
                        }
                        break;
                    case InputKeyUp:
                        if(state->hop_delay_ms > 30) state->hop_delay_ms -= 10;
                        break;
                    case InputKeyDown:
                        if(state->hop_delay_ms < 500) state->hop_delay_ms += 10;
                        break;
                    default:
                        break;
                    }
                    furi_mutex_release(state->mutex);
                }
            } else if(event.type == SpiritBoxEventTick) {
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                if(!state->paused) {
                    tick_counter++;
                    state->hop_accum += TICK_MS;
                    if(state->hop_accum >= state->hop_delay_ms) {
                        state->hop_accum = 0;
                        state->freq_index = (state->freq_index + 1) % FREQ_COUNT;

                        if(state->radio_ok) {
                            furi_hal_subghz_idle();
                            furi_hal_subghz_set_frequency_and_path(freq_table[state->freq_index]);
                            furi_hal_subghz_rx();
                            furi_delay_ms(2);
                            state->rssi = furi_hal_subghz_get_rssi();
                        } else {
                            state->rssi = -100.0f + (float)(rand() % 40);
                        }

                        bool triggered = state->rssi > RSSI_HIT_THRESHOLD;
                        if(triggered || (rand() % 60 == 0)) {
                            spirit_box_trigger_word(state);
                        }
                    }
                    if(state->word_ticks_left > 0) state->word_ticks_left--;

                    spirit_box_audio_tick(state, tick_counter);
                    spirit_box_led_tick(state);
                }
                furi_mutex_release(state->mutex);
                view_port_update(view_port);
            }
        }
    }

    if(state->speaker_ok) {
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }
    light_set_rgb(0, 0, 0);

    if(state->radio_ok) {
        furi_hal_subghz_idle();
        furi_hal_subghz_sleep();
    }

    furi_timer_free(timer);
    gui_remove_view_port(gui, view_port);
    view_port_free(view_port);
    furi_record_close(RECORD_GUI);
    furi_record_close(RECORD_NOTIFICATION);
    furi_message_queue_free(state->queue);
    furi_mutex_free(state->mutex);
    free(state);

    return 0;
}
