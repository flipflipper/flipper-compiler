# Spirit Box — App Flipper Zero (Momentum)

Application recreative qui balaie une liste de frequences sub-GHz, lit le
RSSI (force du signal) a chaque frequence via le module radio interne du
Flipper, et affiche un mot aleatoire quand un "hit" est detecte (signal
fort ou declenchement aleatoire), a la maniere des "spirit box" utilisees
en ghost hunting. C'est un gadget ludique, pas un outil scientifique.

**Son** : le Flipper n'a qu'un buzzer PWM (pas de DAC audio), donc il ne
peut pas jouer de vrai echantillon ou de voix. L'appli reproduit un
grésillement statique en continu (frequence/volume aleatoires a chaque
tick) et, pendant un "hit", alterne deux tons pour donner un effet de
"blip" saccade — l'approximation la plus proche possible du vrai son
d'une spirit box sur ce materiel.

**LED** : la LED RGB est pilotee directement (`furi_hal_light_set`). En
balayage normal, sa couleur/intensite varie selon le RSSI (plus le signal
est fort, plus le vert domine). Pendant un hit, elle flashe en
alternance blanc/rouge.

## Compiler et installer (via ufbt)

1. Installer Python 3.8+ si ce n'est pas deja fait.
2. Installer ufbt (une seule fois) :
   ```
   pip install ufbt
   ```
3. Depuis le dossier de ce projet (celui contenant `application.fam`) :
   ```
   ufbt
   ```
   Cela telecharge le SDK du firmware officiel et compile un fichier
   `.fap` dans le dossier `dist/`.
4. Brancher le Flipper Zero en USB, puis lancer :
   ```
   ufbt launch
   ```
   ou copier manuellement le `.fap` genere dans le dossier
   `apps/Tools/` du Flipper via qFlipper.

Pour cibler le SDK Momentum plutot que le firmware officiel, lance une
fois avant `ufbt` :
```
ufbt update --index-url https://up.momentum-fw.dev/firmware/directory.json
```
(verifie l'URL exacte dans la doc Momentum si elle a change). Ensuite
`ufbt` et `ufbt launch` fonctionnent normalement et generent un `.fap`
compatible Momentum.

## Commandes dans l'application

- **OK** : force l'apparition d'un mot / reprend le balayage si en pause
- **Gauche** : met en pause / reprend le balayage (coupe aussi le son et la LED)
- **Haut** : accelere le balayage de frequences
- **Bas** : ralentit le balayage de frequences
- **Retour** : quitte l'application

## Notes

- La table de frequences couvre plusieurs bandes sub-GHz courantes
  (300–928 MHz). Adapte-la si besoin a la reglementation radio de ton
  pays (bande ISM autorisee).
- Si le module radio n'est pas disponible pour une raison quelconque,
  l'appli bascule automatiquement en "mode simulation" (RSSI aleatoire)
  pour rester utilisable.
- La banque de mots (`word_bank` dans `spirit_box.c`) est facilement
  modifiable : ajoute, retire ou traduit les mots comme tu veux.
- Le seuil de declenchement (`RSSI_HIT_THRESHOLD`) est reglable en haut
  du fichier source si tu veux plus ou moins de "hits".
