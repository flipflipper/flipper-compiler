
#include <furi.h>
#include <gui/gui.h>
#include <gui/view_port.h>
#include <input/input.h>
#include <furi_hal.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    FuriMessageQueue* queue;
    ViewPort* viewport;
    Gui* gui;
    uint8_t level, peak, volume;
    uint32_t samples, intro_until, last_beep;
    bool intro, speaker_owned;
} EmfApp;

static float volf(uint8_t v) {
    if(v == 0) return 0.0f;
    return 0.04f + ((float)v / 10.0f) * 0.50f;
}

static void leds_off(void) {
    furi_hal_light_set(LightRed, 0);
    furi_hal_light_set(LightGreen, 0);
    furi_hal_light_set(LightBlue, 0);
}

static void update_leds(uint8_t l) {
    if(l >= 80) {
        furi_hal_light_set(LightRed,255); furi_hal_light_set(LightGreen,0); furi_hal_light_set(LightBlue,0);
    } else if(l >= 55) {
        furi_hal_light_set(LightRed,220); furi_hal_light_set(LightGreen,100); furi_hal_light_set(LightBlue,0);
    } else if(l >= 30) {
        furi_hal_light_set(LightRed,0); furi_hal_light_set(LightGreen,190); furi_hal_light_set(LightBlue,0);
    } else {
        furi_hal_light_set(LightRed,0); furi_hal_light_set(LightGreen,50); furi_hal_light_set(LightBlue,170);
    }
}

/* Decorative outlined/shadowed lettering inspired by 1990s West-Coast game-title aesthetics.
   Uses Flipper's built-in fonts; no copyrighted logo/font asset is embedded. */
static void draw_styled_name(Canvas* c) {
    canvas_set_font(c, FontPrimary);
    canvas_draw_str(c, 24, 43, "Livio Greco");
    canvas_draw_str(c, 25, 44, "Livio Greco");
    canvas_set_font(c, FontSecondary);
    canvas_draw_str(c, 36, 57, "EMF EDITION");
}

static void draw_intro(Canvas* c) {
    canvas_clear(c);
    canvas_set_font(c, FontSecondary);
    canvas_draw_str(c, 38, 11, "PRESENTS");
    canvas_draw_frame(c, 8, 16, 112, 45);
    draw_styled_name(c);
}

static void draw_meter(Canvas* c, EmfApp* a) {
    canvas_clear(c);
    canvas_set_font(c, FontPrimary);
    canvas_draw_str(c, 2, 10, "EMF METER");

    char s[24];
    snprintf(s,sizeof(s),"%u%%",a->level);
    canvas_draw_str(c,102,10,s);

    canvas_draw_frame(c,7,18,114,14);
    uint8_t w=(uint8_t)((a->level*112U)/100U);
    if(w) canvas_draw_box(c,8,19,w,12);

    for(uint8_t i=0;i<=10;i++){
        uint8_t x=8+i*11;
        canvas_draw_line(c,x,33,x,(i%5==0)?39:36);
    }

    canvas_set_font(c,FontSecondary);
    canvas_draw_str(c,7,47,"LOW");
    canvas_draw_str(c,99,47,"HIGH");

    snprintf(s,sizeof(s),"PEAK %u%%",a->peak);
    canvas_draw_str(c,7,58,s);
    snprintf(s,sizeof(s),"VOL %u",a->volume);
    canvas_draw_str(c,91,58,s);
}

static void draw_cb(Canvas* c, void* ctx) {
    EmfApp* a=ctx;
    if(a->intro) draw_intro(c); else draw_meter(c,a);
}

static void input_cb(InputEvent* e, void* ctx) {
    EmfApp* a=ctx;
    if(e->type==InputTypeShort || e->type==InputTypeLong)
        furi_message_queue_put(a->queue,e,0);
}

/* Relative/demo activity source. For calibrated physical EMF values,
   replace this with samples from an external magnetometer/EMF sensor. */
static uint8_t sample_relative(void) {
    uint8_t v=4+(rand()%14);
    uint8_t r=rand()%100;
    if(r<20) v+=10+(rand()%22);
    if(r<6) v+=30+(rand()%45);
    if(v>100) v=100;
    return v;
}

static void meter_sound(EmfApp* a) {
    if(!a->speaker_owned || a->volume==0) return;

    uint32_t now=furi_get_tick();
    /* Stronger field -> shorter interval, like handheld EMF alert meters. */
    uint32_t interval=900U-(uint32_t)a->level*8U;
    if(interval<80) interval=80;

    if(now-a->last_beep >= interval) {
        a->last_beep=now;
        float freq=650.0f+((float)a->level*18.0f);
        furi_hal_speaker_start(freq,volf(a->volume));
        furi_delay_ms(a->level>=70 ? 55 : 30);
        furi_hal_speaker_stop();
    }
}

int32_t emf_meter_app(void* p) {
    UNUSED(p);
    EmfApp* a=malloc(sizeof(EmfApp));
    if(!a) return -1;

    a->queue=furi_message_queue_alloc(8,sizeof(InputEvent));
    a->viewport=view_port_alloc();
    a->gui=furi_record_open(RECORD_GUI);
    a->level=0; a->peak=0; a->volume=5; a->samples=0;
    a->intro=true; a->intro_until=furi_get_tick()+2500;
    a->last_beep=0; a->speaker_owned=false;
    srand((unsigned int)furi_get_tick());

    view_port_draw_callback_set(a->viewport,draw_cb,a);
    view_port_input_callback_set(a->viewport,input_cb,a);
    gui_add_view_port(a->gui,a->viewport,GuiLayerFullscreen);

    a->speaker_owned=furi_hal_speaker_acquire(1000);

    bool exit=false;
    InputEvent e;

    while(!exit) {
        if(a->intro && furi_get_tick()>=a->intro_until) {
            a->intro=false;
            view_port_update(a->viewport);
        }

        FuriStatus st=furi_message_queue_get(a->queue,&e,80);
        if(st==FuriStatusOk) {
            if(e.type==InputTypeShort) {
                if(e.key==InputKeyBack) exit=true;
                else if(e.key==InputKeyUp && a->volume<10) a->volume++;
                else if(e.key==InputKeyDown && a->volume>0) a->volume--;
                else if(e.key==InputKeyOk) a->peak=a->level;
            } else if(e.type==InputTypeLong) {
                if(e.key==InputKeyUp) a->volume=10;
                else if(e.key==InputKeyDown) a->volume=0;
            }
            view_port_update(a->viewport);
        } else if(!a->intro) {
            uint8_t raw=sample_relative();
            a->level=(uint8_t)((a->level*3U+raw)/4U);
            if(a->level>a->peak) a->peak=a->level;
            a->samples++;
            update_leds(a->level);
            meter_sound(a);

            if(a->level>=85) {
                furi_hal_vibro_on(true);
                furi_delay_ms(25);
                furi_hal_vibro_on(false);
            }
            view_port_update(a->viewport);
        }
    }

    furi_hal_vibro_on(false);
    leds_off();
    if(a->speaker_owned) {
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }
    gui_remove_view_port(a->gui,a->viewport);
    view_port_free(a->viewport);
    furi_record_close(RECORD_GUI);
    furi_message_queue_free(a->queue);
    free(a);
    return 0;
}
