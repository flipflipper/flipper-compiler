EMF METER V2 - MOMENTUM

Ajouts:
- Son type lecteur EMF: les bips deviennent plus rapides et plus aigus avec la jauge.
- Volume 0-10: HAUT/BAS; appui long HAUT=max, BAS=muet.
- LEDs réactives.
- Vibration au-dessus de 85%.
- Écran d'accueil personnalisé 'Livio Greco' avec lettrage décoratif inspiré de l'esthétique
  des titres de jeux West-Coast des années 1990, réalisé avec les polices intégrées du Flipper.
- Jauge 0-100% + Peak Hold. OK remet le Peak à la valeur actuelle.

IMPORTANT:
Cette version reste un indicateur relatif/simulé. Le Flipper Zero seul ne possède pas
un capteur EMF large bande calibré. Pour afficher une vraie mesure physique en uT/mG,
il faut connecter un capteur externe et remplacer la fonction sample_relative().
