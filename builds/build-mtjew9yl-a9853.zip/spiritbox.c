#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <input/input.h>
#include <notification/notification_messages.h>
#include <stdlib.h>
#include <stdio.h>

typedef enum {
    SpiritBandFM,
    SpiritBandAM,
} SpiritBand;

typedef struct {
    FuriMutex* mutex;
    uint32_t frequency;
    uint32_t interval_ms;
    uint32_t sweep_count;
    uint32_t hit_count;
    uint32_t rng;
    bool running;
    bool reverse;
    bool sound;
    bool hit;
    bool exit;
    SpiritBand band;
} SpiritBoxState;

static uint32_t xorshift32(uint32_t* x) {
    uint32_t v = *x;
    v ^= v << 13;
    v ^= v >> 17;
    v ^= v << 5;
    *x = v;
    return v;
}

static void band_limits(const SpiritBoxState* s, uint32_t* min, uint32_t* max, uint32_t* step) {
    if(s->band == SpiritBandFM) {
        *min = 87500;   // kHz
        *max = 108000;  // kHz
        *step = 100;    // 0.1 MHz
    } else {
        *min = 520;     // kHz
        *max = 1710;    // kHz
        *step = 10;     // 10 kHz
    }
}

static void draw_callback(Canvas* canvas, void* ctx) {
    SpiritBoxState* s = ctx;
    furi_mutex_acquire(s->mutex, FuriWaitForever);

    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 2, 9, s->band == SpiritBandFM ? "SPIRIT BOX   FM" : "SPIRIT BOX   AM");

    char freq[28];
    if(s->band == SpiritBandFM) {
        snprintf(freq, sizeof(freq), "%lu.%01lu", (unsigned long)(s->frequency / 1000),
                 (unsigned long)((s->frequency % 1000) / 100));
    } else {
        snprintf(freq, sizeof(freq), "%lu", (unsigned long)s->frequency);
    }

    canvas_set_font(canvas, FontBigNumbers);
    canvas_draw_str(canvas, 4, 31, freq);
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 93, 31, s->band == SpiritBandFM ? "MHz" : "kHz");

    char line[40];
    snprintf(line, sizeof(line), "%s %lums  S:%lu H:%lu", s->reverse ? "REV" : "FWD",
             (unsigned long)s->interval_ms, (unsigned long)s->sweep_count,
             (unsigned long)s->hit_count);
    canvas_draw_str(canvas, 2, 44, line);

    if(s->hit) {
        canvas_draw_box(canvas, 91, 36, 35, 10);
        canvas_set_color(canvas, ColorWhite);
        canvas_draw_str(canvas, 95, 44, "VOICE");
        canvas_set_color(canvas, ColorBlack);
    }

    snprintf(line, sizeof(line), "OK:%s  U/D:dir  L/R:speed", s->running ? "STOP" : "RUN");
    canvas_draw_str(canvas, 2, 54, line);
    canvas_draw_str(canvas, 2, 63, "Hold OK:AM/FM  Hold Up:sound");

    furi_mutex_release(s->mutex);
}

static void input_callback(InputEvent* event, void* ctx) {
    FuriMessageQueue* queue = ctx;
    furi_message_queue_put(queue, event, 0);
}

static void tick_frequency(SpiritBoxState* s) {
    uint32_t min, max, step;
    band_limits(s, &min, &max, &step);

    if(s->reverse) {
        if(s->frequency <= min + step) {
            s->frequency = max;
            s->sweep_count++;
        } else {
            s->frequency -= step;
        }
    } else {
        s->frequency += step;
        if(s->frequency >= max) {
            s->frequency = min;
            s->sweep_count++;
        }
    }
}

static void static_click(SpiritBoxState* s) {
    if(!s->sound) return;
    if(!furi_hal_speaker_acquire(10)) return;
    uint32_t r = xorshift32(&s->rng);
    float freq = 650.0f + (float)(r % 1600);
    furi_hal_speaker_start(freq, 0.18f);
    furi_delay_ms(4 + (r % 7));
    furi_hal_speaker_stop();
    furi_hal_speaker_release();
}

static void voice_hit(SpiritBoxState* s, NotificationApp* notifications) {
    s->hit = true;
    s->hit_count++;
    notification_message(notifications, &sequence_blink_blue_10);
    notification_message(notifications, &sequence_single_vibro);

    if(s->sound && furi_hal_speaker_acquire(20)) {
        uint32_t r = xorshift32(&s->rng);
        float base = 280.0f + (float)(r % 330);
        furi_hal_speaker_start(base, 0.32f);
        furi_delay_ms(22);
        furi_hal_speaker_start(base * 1.35f, 0.26f);
        furi_delay_ms(18);
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }
}

int32_t spiritbox_app(void* p) {
    UNUSED(p);

    SpiritBoxState state = {
        .mutex = furi_mutex_alloc(FuriMutexTypeNormal),
        .frequency = 87500,
        .interval_ms = 120,
        .sweep_count = 0,
        .hit_count = 0,
        .rng = furi_get_tick() ^ 0x53B17A21,
        .running = true,
        .reverse = false,
        .sound = true,
        .hit = false,
        .exit = false,
        .band = SpiritBandFM,
    };

    FuriMessageQueue* queue = furi_message_queue_alloc(8, sizeof(InputEvent));
    ViewPort* viewport = view_port_alloc();
    view_port_draw_callback_set(viewport, draw_callback, &state);
    view_port_input_callback_set(viewport, input_callback, queue);

    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, viewport, GuiLayerFullscreen);
    NotificationApp* notifications = furi_record_open(RECORD_NOTIFICATION);

    uint32_t last_tick = furi_get_tick();
    uint32_t hit_until = 0;

    while(!state.exit) {
        InputEvent event;
        if(furi_message_queue_get(queue, &event, 15) == FuriStatusOk) {
            furi_mutex_acquire(state.mutex, FuriWaitForever);

            if(event.type == InputTypeShort) {
                if(event.key == InputKeyBack) {
                    state.exit = true;
                } else if(event.key == InputKeyOk) {
                    state.running = !state.running;
                } else if(event.key == InputKeyLeft) {
                    if(state.interval_ms < 300) state.interval_ms += 20;
                } else if(event.key == InputKeyRight) {
                    if(state.interval_ms > 40) state.interval_ms -= 20;
                } else if(event.key == InputKeyUp) {
                    state.reverse = false;
                } else if(event.key == InputKeyDown) {
                    state.reverse = true;
                }
            } else if(event.type == InputTypeLong) {
                if(event.key == InputKeyOk) {
                    state.band = (state.band == SpiritBandFM) ? SpiritBandAM : SpiritBandFM;
                    state.frequency = (state.band == SpiritBandFM) ? 87500 : 520;
                    state.sweep_count = 0;
                } else if(event.key == InputKeyUp) {
                    state.sound = !state.sound;
                }
            }

            furi_mutex_release(state.mutex);
            view_port_update(viewport);
        }

        uint32_t now = furi_get_tick();
        furi_mutex_acquire(state.mutex, FuriWaitForever);
        uint32_t interval = state.interval_ms;
        bool running = state.running;
        if(state.hit && (int32_t)(now - hit_until) >= 0) state.hit = false;
        furi_mutex_release(state.mutex);

        if(running && (now - last_tick >= furi_ms_to_ticks(interval))) {
            furi_mutex_acquire(state.mutex, FuriWaitForever);
            tick_frequency(&state);
            uint32_t r = xorshift32(&state.rng);
            bool make_hit = (r % 31) == 0;
            furi_mutex_release(state.mutex);

            static_click(&state);

            if(make_hit) {
                furi_mutex_acquire(state.mutex, FuriWaitForever);
                voice_hit(&state, notifications);
                hit_until = furi_get_tick() + furi_ms_to_ticks(350);
                furi_mutex_release(state.mutex);
            }

            view_port_update(viewport);
            last_tick = furi_get_tick();
        }
    }

    if(furi_hal_speaker_is_mine()) {
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }

    gui_remove_view_port(gui, viewport);
    furi_record_close(RECORD_NOTIFICATION);
    furi_record_close(RECORD_GUI);
    view_port_free(viewport);
    furi_message_queue_free(queue);
    furi_mutex_free(state.mutex);
    return 0;
}
