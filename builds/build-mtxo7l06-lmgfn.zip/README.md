# DAB Timer V3 — Momentum SDK

Cleaned external Flipper Zero FAP application for Momentum Firmware.

Features:
- Animated cannabis-leaf intro
- 0–60 second countdown
- 5-second adjustment
- 30-second default
- Large MM:SS display
- Progress bar
- Start / pause / reset / stop
- Repeating audible + vibration alarm
- Red LED indication
- Hard 60-second maximum

## Momentum build

Put the `dab_timer` directory in:

`applications_user/dab_timer/`

From the Momentum firmware root:

```bash
./fbt format
./fbt lint
./fbt fap_dab_timer
```

To build and launch the app over USB:

```bash
./fbt launch APPSRC=applications_user/dab_timer
```

The app intentionally uses only standard Furi GUI, input, timer, mutex, and notification APIs. The leaf intro is rendered directly with Canvas, so no external image asset is required.
