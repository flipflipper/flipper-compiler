#include <furi.h>
#include <gui/gui.h>
#include <gui/elements.h>
#include <input/input.h>
#include <notification/notification.h>
#include <notification/notification_messages.h>

#include <stdio.h>
#include <stdlib.h>

#define TAG "DabTimerV2"

#define MAX_SECONDS 60U
#define STEP_SECONDS 5U
#define DEFAULT_SECONDS 30U
#define PRESET_COUNT 5U
#define INTRO_MS 1600U
#define ALARM_REPEAT_MS 1800U

static const uint32_t presets[PRESET_COUNT] = {10U, 15U, 30U, 45U, 60U};

typedef enum {
    ScreenIntro,
    ScreenSet,
    ScreenRunning,
    ScreenAlarm,
} Screen;

typedef struct {
    Gui* gui;
    ViewPort* view_port;
    NotificationApp* notification;
    FuriTimer* tick_timer;
    FuriTimer* alarm_timer;
    FuriMutex* mutex;

    Screen screen;
    uint32_t duration_seconds;
    uint32_t remaining_seconds;
    uint32_t end_tick;
    uint8_t preset_index;
    uint8_t intro_frame;
    uint8_t alarm_flash;
    bool exiting;
} DabTimer;

/* 24x24 pixel leaf, rendered directly on the 128x64 display. */
static const uint8_t leaf_bitmap[] = {
    0x00,0x00,0x00, 0x00,0x18,0x00, 0x00,0x3C,0x00,
    0x00,0x7E,0x00, 0x18,0xFF,0x18, 0x3C,0xFF,0x3C,
    0x7E,0x7E,0x7E, 0xFF,0x3C,0xFF, 0x7E,0x18,0x7E,
    0x3C,0x18,0x3C, 0x18,0x18,0x18, 0x00,0x18,0x00,
    0x00,0x18,0x00, 0x00,0x18,0x00, 0x00,0x18,0x00,
    0x00,0x18,0x00, 0x00,0x18,0x00, 0x00,0x18,0x00,
    0x00,0x18,0x00, 0x00,0x18,0x00, 0x00,0x18,0x00,
    0x00,0x18,0x00, 0x00,0x18,0x00, 0x00,0x18,0x00,
    0x00,0x18,0x00, 0x00,0x18,0x00, 0x00,0x18,0x00,
    0x00,0x18,0x00, 0x00,0x18,0x00, 0x00,0x18,0x00
};

/*
 * The supplied examples demonstrate NotificationSequence with notes,
 * delays, LED indication, sound-off and vibration.
 */
static const NotificationSequence alarm_sequence = {
    &message_display_backlight_on,
    &message_red_255,
    &message_vibro_on,
    &message_note_c5,
    &message_delay_100,
    &message_note_c5,
    &message_delay_100,
    &message_note_c5,
    &message_delay_100,
    &message_note_c5,
    &message_delay_100,
    &message_note_c5,
    &message_vibro_off,
    &message_sound_off,
    NULL,
};

static void center(Canvas* canvas, const char* text, int y) {
    canvas_draw_str_aligned(canvas, 64, y, AlignCenter, AlignTop, text);
}

static void format_time(uint32_t seconds, char* out, size_t size) {
    snprintf(out, size, "%02lu:%02lu",
        (unsigned long)(seconds / 60U),
        (unsigned long)(seconds % 60U));
}

static void draw_leaf(Canvas* canvas, int x, int y) {
    canvas_draw_xbm(canvas, x, y, 24, 24, leaf_bitmap);
}

static void draw_intro(Canvas* canvas, DabTimer* app) {
    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    center(canvas, "DAB TIMER", 1);

    int x = 52 + ((app->intro_frame & 1U) ? 1 : 0);
    draw_leaf(canvas, x, 20);

    canvas_set_font(canvas, FontSecondary);
    center(canvas, "V2", 47);
    center(canvas, "READY", 56);
}

static void draw_progress(Canvas* canvas, uint32_t remaining) {
    const int x = 8, y = 8, w = 112, h = 7;
    canvas_draw_frame(canvas, x, y, w, h);

    uint32_t fill = (remaining * (uint32_t)(w - 4)) / MAX_SECONDS;
    if(fill) canvas_draw_box(canvas, x + 2, y + 2, (int)fill, h - 4);
}

static void draw_set(Canvas* canvas, DabTimer* app) {
    char time[8];
    format_time(app->remaining_seconds, time, sizeof(time));

    canvas_clear(canvas);
    canvas_set_font(canvas, FontSecondary);
    center(canvas, "SET TIMER", 0);

    draw_progress(canvas, app->remaining_seconds);

    canvas_set_font(canvas, FontBigNumbers);
    center(canvas, time, 19);

    canvas_set_font(canvas, FontSecondary);
    elements_button_left(canvas, "-5");
    elements_button_center(canvas, "Start");
    elements_button_right(canvas, "+5");

    char preset[24];
    snprintf(preset, sizeof(preset), "PRESET  %lu/%lu",
        (unsigned long)(app->preset_index + 1U),
        (unsigned long)PRESET_COUNT);
    center(canvas, preset, 51);
}

static void draw_running(Canvas* canvas, DabTimer* app) {
    char time[8];
    format_time(app->remaining_seconds, time, sizeof(time));

    canvas_clear(canvas);
    canvas_set_font(canvas, FontSecondary);
    center(canvas, "RUNNING", 0);

    draw_progress(canvas, app->remaining_seconds);

    canvas_set_font(canvas, FontBigNumbers);
    center(canvas, time, 19);

    canvas_set_font(canvas, FontSecondary);
    elements_button_left(canvas, "Reset");
    elements_button_center(canvas, "Pause");
    elements_button_right(canvas, "Stop");
}

static void draw_alarm(Canvas* canvas, DabTimer* app) {
    canvas_clear(canvas);

    canvas_set_font(canvas, FontPrimary);
    center(canvas, (app->alarm_flash & 1U) ? "DAB TIME!" : "TIME UP!", 4);

    canvas_set_font(canvas, FontBigNumbers);
    center(canvas, "00:00", 22);

    canvas_set_font(canvas, FontSecondary);
    center(canvas, "ALARM ACTIVE", 48);
    elements_button_center(canvas, "Reset");
}

static void draw_callback(Canvas* canvas, void* context) {
    DabTimer* app = context;

    if(furi_mutex_acquire(app->mutex, FuriWaitForever) != FuriStatusOk) return;

    switch(app->screen) {
    case ScreenIntro: draw_intro(canvas, app); break;
    case ScreenSet: draw_set(canvas, app); break;
    case ScreenRunning: draw_running(canvas, app); break;
    case ScreenAlarm: draw_alarm(canvas, app); break;
    }

    furi_mutex_release(app->mutex);
}

static void alarm_callback(void* context) {
    DabTimer* app = context;

    if(furi_mutex_acquire(app->mutex, 0) != FuriStatusOk) return;

    if(app->screen == ScreenAlarm) {
        app->alarm_flash++;
        notification_message(app->notification, &alarm_sequence);
        view_port_update(app->view_port);
    }

    furi_mutex_release(app->mutex);
}

static void tick_callback(void* context) {
    DabTimer* app = context;

    if(furi_mutex_acquire(app->mutex, 0) != FuriStatusOk) return;

    if(app->screen == ScreenRunning) {
        uint32_t now = furi_get_tick();

        if((int32_t)(now - app->end_tick) >= 0) {
            app->remaining_seconds = 0;
            app->screen = ScreenAlarm;
            app->alarm_flash = 0;

            notification_message(app->notification, &alarm_sequence);
            furi_timer_start(app->alarm_timer, ALARM_REPEAT_MS);
            view_port_update(app->view_port);
        } else {
            uint32_t hz = furi_kernel_get_tick_frequency();
            uint32_t ticks_left = app->end_tick - now;
            app->remaining_seconds = (ticks_left + hz - 1U) / hz;
            if(app->remaining_seconds > MAX_SECONDS)
                app->remaining_seconds = MAX_SECONDS;

            view_port_update(app->view_port);
        }
    }

    furi_mutex_release(app->mutex);
}

static void reset_to_duration(DabTimer* app) {
    app->screen = ScreenSet;
    app->remaining_seconds = app->duration_seconds;
    if(app->remaining_seconds > MAX_SECONDS)
        app->remaining_seconds = MAX_SECONDS;
    view_port_update(app->view_port);
}

static void choose_preset(DabTimer* app, uint8_t index) {
    if(index >= PRESET_COUNT) index = 0;
    app->preset_index = index;
    app->duration_seconds = presets[index];
    app->remaining_seconds = app->duration_seconds;
}

static void start_timer(DabTimer* app) {
    if(app->remaining_seconds == 0) return;

    uint32_t hz = furi_kernel_get_tick_frequency();
    app->end_tick = furi_get_tick() + app->remaining_seconds * hz;
    app->screen = ScreenRunning;
    view_port_update(app->view_port);
}

static void input_callback(InputEvent* event, void* context) {
    DabTimer* app = context;

    if(event->type != InputTypeShort) return;

    if(furi_mutex_acquire(app->mutex, FuriWaitForever) != FuriStatusOk)
        return;

    if(app->screen == ScreenIntro) {
        if(event->key == InputKeyBack) app->exiting = true;
        furi_mutex_release(app->mutex);
        return;
    }

    if(app->screen == ScreenAlarm) {
        if(event->key == InputKeyOk) {
            furi_timer_stop(app->alarm_timer);
            choose_preset(app, app->preset_index);
            app->screen = ScreenSet;
            view_port_update(app->view_port);
        } else if(event->key == InputKeyBack) {
            furi_timer_stop(app->alarm_timer);
            app->exiting = true;
        }

        furi_mutex_release(app->mutex);
        return;
    }

    if(app->screen == ScreenSet) {
        switch(event->key) {
        case InputKeyUp:
        case InputKeyRight:
            if(app->remaining_seconds + STEP_SECONDS <= MAX_SECONDS)
                app->remaining_seconds += STEP_SECONDS;
            app->duration_seconds = app->remaining_seconds;
            view_port_update(app->view_port);
            break;

        case InputKeyDown:
        case InputKeyLeft:
            if(app->remaining_seconds >= STEP_SECONDS)
                app->remaining_seconds -= STEP_SECONDS;
            else
                app->remaining_seconds = 0;
            app->duration_seconds = app->remaining_seconds;
            view_port_update(app->view_port);
            break;

        case InputKeyOk:
            start_timer(app);
            break;

        case InputKeyBack:
            app->exiting = true;
            break;

        default:
            break;
        }

        furi_mutex_release(app->mutex);
        return;
    }

    if(app->screen == ScreenRunning) {
        switch(event->key) {
        case InputKeyOk:
            /* Pause without losing the current remaining time. */
            app->screen = ScreenSet;
            app->duration_seconds = app->remaining_seconds;
            view_port_update(app->view_port);
            break;

        case InputKeyLeft:
            reset_to_duration(app);
            break;

        case InputKeyRight:
            app->screen = ScreenSet;
            app->remaining_seconds = app->duration_seconds;
            view_port_update(app->view_port);
            break;

        case InputKeyBack:
            app->exiting = true;
            break;

        default:
            break;
        }
    }

    furi_mutex_release(app->mutex);
}

int32_t dab_timer_app(void* p) {
    UNUSED(p);

    DabTimer* app = malloc(sizeof(DabTimer));

    app->gui = furi_record_open(RECORD_GUI);
    app->notification = furi_record_open(RECORD_NOTIFICATION);
    app->mutex = furi_mutex_alloc(FuriMutexTypeNormal);

    app->screen = ScreenIntro;
    app->duration_seconds = DEFAULT_SECONDS;
    app->remaining_seconds = DEFAULT_SECONDS;
    app->preset_index = 2; /* 30 seconds */
    app->end_tick = 0;
    app->intro_frame = 0;
    app->alarm_flash = 0;
    app->exiting = false;

    app->view_port = view_port_alloc();
    view_port_draw_callback_set(app->view_port, draw_callback, app);
    view_port_input_callback_set(app->view_port, input_callback, app);
    gui_add_view_port(app->gui, app->view_port, GuiLayerFullscreen);

    /* Animated leaf intro. */
    for(uint8_t i = 0; i < 4 && !app->exiting; i++) {
        app->intro_frame = i;
        view_port_update(app->view_port);
        furi_delay_ms(INTRO_MS / 4U);
    }

    if(!app->exiting) {
        app->screen = ScreenSet;
        view_port_update(app->view_port);
    }

    app->tick_timer = furi_timer_alloc(
        tick_callback,
        FuriTimerTypePeriodic,
        app);

    app->alarm_timer = furi_timer_alloc(
        alarm_callback,
        FuriTimerTypePeriodic,
        app);

    furi_timer_start(app->tick_timer, 100);

    while(!app->exiting) {
        furi_delay_ms(25);
    }

    furi_timer_stop(app->tick_timer);
    furi_timer_stop(app->alarm_timer);
    furi_timer_free(app->tick_timer);
    furi_timer_free(app->alarm_timer);

    view_port_enabled_set(app->view_port, false);
    gui_remove_view_port(app->gui, app->view_port);
    view_port_free(app->view_port);

    furi_record_close(RECORD_NOTIFICATION);
    furi_record_close(RECORD_GUI);

    furi_mutex_free(app->mutex);
    free(app);

    return 0;
}
