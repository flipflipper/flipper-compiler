
#include <furi.h>
#include <gui/gui.h>
#include <gui/view_port.h>
#include <input/input.h>
#include <furi_hal.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    FuriMessageQueue* queue;
    ViewPort* viewport;
    Gui* gui;

    bool running;
    bool reverse;
    bool speaker_owned;

    uint32_t frequency_khz;
    uint32_t sweeps;
    uint32_t speed_ms;
    uint8_t volume;       // 0..10
    uint8_t signal;       // 0..100
    bool voice_hit;
    uint8_t hit_ticks;
} SpiritBoxApp;

static float volume_to_float(uint8_t volume) {
    if(volume == 0) return 0.0f;
    return 0.05f + ((float)volume / 10.0f) * 0.55f;
}

static void leds_off(void) {
    furi_hal_light_set(LightRed, 0);
    furi_hal_light_set(LightGreen, 0);
    furi_hal_light_set(LightBlue, 0);
}

static void update_leds(SpiritBoxApp* app) {
    if(app->voice_hit) {
        furi_hal_light_set(LightRed, 255);
        furi_hal_light_set(LightGreen, 0);
        furi_hal_light_set(LightBlue, 160);
    } else if(app->signal >= 75) {
        furi_hal_light_set(LightRed, 255);
        furi_hal_light_set(LightGreen, 30);
        furi_hal_light_set(LightBlue, 0);
    } else if(app->signal >= 45) {
        furi_hal_light_set(LightRed, 160);
        furi_hal_light_set(LightGreen, 130);
        furi_hal_light_set(LightBlue, 0);
    } else {
        furi_hal_light_set(LightRed, 0);
        furi_hal_light_set(LightGreen, 70);
        furi_hal_light_set(LightBlue, 190);
    }
}

static void update_sound(SpiritBoxApp* app) {
    if(!app->speaker_owned) return;

    if(!app->running || app->volume == 0) {
        furi_hal_speaker_stop();
        return;
    }

    float vol = volume_to_float(app->volume);

    if(app->voice_hit) {
        // Lower warbling tone for a short "voice-like" event.
        float f = 320.0f + (float)(rand() % 900);
        furi_hal_speaker_start(f, vol);
    } else {
        // Rapidly changing tone to imitate radio/static chatter on the buzzer.
        float f = 1700.0f + (float)(rand() % 5200);
        float dynamic_vol = vol * (0.35f + ((float)app->signal / 100.0f) * 0.65f);
        furi_hal_speaker_start(f, dynamic_vol);
    }
}

static void draw_callback(Canvas* canvas, void* context) {
    SpiritBoxApp* app = context;
    canvas_clear(canvas);

    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 2, 10, "SPIRIT BOX");
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 91, 10, app->running ? "SWEEP" : "PAUSE");

    char freq[24];
    snprintf(
        freq,
        sizeof(freq),
        "%lu.%01lu",
        (unsigned long)(app->frequency_khz / 1000),
        (unsigned long)((app->frequency_khz % 1000) / 100));

    canvas_set_font(canvas, FontBigNumbers);
    canvas_draw_str(canvas, 7, 31, freq);
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 94, 29, "MHz");

    char row[40];
    snprintf(
        row,
        sizeof(row),
        "%s  %lums  SW:%lu",
        app->reverse ? "REV" : "FWD",
        (unsigned long)app->speed_ms,
        (unsigned long)app->sweeps);
    canvas_draw_str(canvas, 3, 42, row);

    // Signal meter
    canvas_draw_str(canvas, 3, 52, "SIG");
    canvas_draw_frame(canvas, 25, 46, 65, 8);
    uint8_t width = (uint8_t)((app->signal * 63U) / 100U);
    if(width) canvas_draw_box(canvas, 26, 47, width, 6);

    char vol[16];
    snprintf(vol, sizeof(vol), "VOL:%u", app->volume);
    canvas_draw_str(canvas, 94, 52, vol);

    if(app->voice_hit) {
        canvas_set_font(canvas, FontPrimary);
        canvas_draw_str(canvas, 31, 63, "VOICE HIT");
    } else {
        canvas_set_font(canvas, FontSecondary);
        canvas_draw_str(canvas, 2, 63, "OK run  U/D vol  L dir  R spd");
    }
}

static void input_callback(InputEvent* input_event, void* context) {
    SpiritBoxApp* app = context;
    if(input_event->type == InputTypeShort || input_event->type == InputTypeLong) {
        furi_message_queue_put(app->queue, input_event, 0);
    }
}

static void step_sweep(SpiritBoxApp* app) {
    if(app->reverse) {
        if(app->frequency_khz <= 87500) {
            app->frequency_khz = 108000;
            app->sweeps++;
        } else {
            app->frequency_khz -= 100;
        }
    } else {
        if(app->frequency_khz >= 108000) {
            app->frequency_khz = 87500;
            app->sweeps++;
        } else {
            app->frequency_khz += 100;
        }
    }

    // Mostly weak/medium "signal", with occasional spikes.
    uint8_t r = (uint8_t)(rand() % 100);
    if(r < 70) {
        app->signal = (uint8_t)(10 + rand() % 40);
    } else if(r < 94) {
        app->signal = (uint8_t)(45 + rand() % 30);
    } else {
        app->signal = (uint8_t)(75 + rand() % 26);
    }

    // Rare simulated voice hit.
    if(!app->voice_hit && ((rand() % 100) < 5)) {
        app->voice_hit = true;
        app->hit_ticks = 2 + (rand() % 4);
        furi_hal_vibro_on(true);
    } else if(app->voice_hit) {
        if(app->hit_ticks > 0) app->hit_ticks--;
        if(app->hit_ticks == 0) {
            app->voice_hit = false;
            furi_hal_vibro_on(false);
        }
    }

    update_leds(app);
    update_sound(app);
}

static void cycle_speed(SpiritBoxApp* app) {
    if(app->speed_ms == 50) app->speed_ms = 75;
    else if(app->speed_ms == 75) app->speed_ms = 100;
    else if(app->speed_ms == 100) app->speed_ms = 125;
    else if(app->speed_ms == 125) app->speed_ms = 150;
    else if(app->speed_ms == 150) app->speed_ms = 200;
    else if(app->speed_ms == 200) app->speed_ms = 250;
    else if(app->speed_ms == 250) app->speed_ms = 300;
    else app->speed_ms = 50;
}

int32_t spiritbox_app(void* p) {
    UNUSED(p);

    SpiritBoxApp* app = malloc(sizeof(SpiritBoxApp));
    if(!app) return -1;

    app->queue = furi_message_queue_alloc(8, sizeof(InputEvent));
    app->viewport = view_port_alloc();
    app->gui = furi_record_open(RECORD_GUI);

    app->running = true;
    app->reverse = false;
    app->speaker_owned = false;
    app->frequency_khz = 87500;
    app->sweeps = 0;
    app->speed_ms = 100;
    app->volume = 5;
    app->signal = 20;
    app->voice_hit = false;
    app->hit_ticks = 0;

    srand((unsigned int)furi_get_tick());

    view_port_draw_callback_set(app->viewport, draw_callback, app);
    view_port_input_callback_set(app->viewport, input_callback, app);
    gui_add_view_port(app->gui, app->viewport, GuiLayerFullscreen);

    // Acquire the buzzer for the lifetime of the app.
    app->speaker_owned = furi_hal_speaker_acquire(1000);

    bool exit = false;
    InputEvent event;

    while(!exit) {
        FuriStatus status =
            furi_message_queue_get(app->queue, &event, app->running ? app->speed_ms : 100);

        if(status == FuriStatusOk) {
            if(event.type == InputTypeShort) {
                if(event.key == InputKeyBack) {
                    exit = true;
                } else if(event.key == InputKeyOk) {
                    app->running = !app->running;
                    if(!app->running) {
                        furi_hal_vibro_on(false);
                        if(app->speaker_owned) furi_hal_speaker_stop();
                        leds_off();
                    }
                } else if(event.key == InputKeyUp) {
                    if(app->volume < 10) app->volume++;
                    update_sound(app);
                } else if(event.key == InputKeyDown) {
                    if(app->volume > 0) app->volume--;
                    update_sound(app);
                } else if(event.key == InputKeyLeft) {
                    app->reverse = !app->reverse;
                } else if(event.key == InputKeyRight) {
                    cycle_speed(app);
                }
            } else if(event.type == InputTypeLong) {
                if(event.key == InputKeyUp) {
                    app->volume = 10;
                    update_sound(app);
                } else if(event.key == InputKeyDown) {
                    app->volume = 0;
                    update_sound(app);
                }
            }

            view_port_update(app->viewport);
        } else if(app->running) {
            step_sweep(app);
            view_port_update(app->viewport);
        }
    }

    furi_hal_vibro_on(false);
    leds_off();

    if(app->speaker_owned) {
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }

    gui_remove_view_port(app->gui, app->viewport);
    view_port_free(app->viewport);
    furi_record_close(RECORD_GUI);
    furi_message_queue_free(app->queue);
    free(app);

    return 0;
}
