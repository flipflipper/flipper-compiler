SPIRIT BOX V3 - Flipper Zero / Momentum
=======================================

Fonctions
---------
- Affichage 87.5 -> 108.0 MHz façon Spirit Box
- Balayage FWD/REV
- Vitesses: 50 / 75 / 100 / 125 / 150 / 200 / 250 / 300 ms
- Compteur de balayages (SW)
- Faux niveau de signal animé
- Effets "VOICE HIT" aléatoires
- LEDs RGB réactives
- Vibration sur Voice Hit
- Bruit synthétique via le buzzer interne
- Volume réglable 0 -> 10

Commandes
---------
OK       : Pause / reprise
HAUT     : Volume +
BAS      : Volume -
HAUT long: Volume max
BAS long : Muet
GAUCHE   : FWD / REV
DROITE   : Change la vitesse
BACK     : Quitter

IMPORTANT
---------
Ceci est une simulation de Spirit Box.
Le CC1101 interne du Flipper Zero ne reçoit pas la bande FM 88-108 MHz.
Le haut-parleur du Flipper est un buzzer : le "bruit radio" est synthétisé.
Aucune affirmation de détection paranormale n'est faite.

Compilation Momentum
--------------------
Le dossier contient application.fam + spiritbox.c et peut être compilé
avec un environnement de build Flipper/Momentum compatible.
