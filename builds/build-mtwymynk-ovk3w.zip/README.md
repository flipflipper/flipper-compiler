# Dab Timer V2 — Flipper Zero

A polished 60-second maximum countdown timer for Flipper Zero.

## Features
- Splash screen with a stylized leaf logo
- Adjustable timer from 1–60 seconds
- Up/Down buttons change the selected duration
- OK starts the timer
- OK while running pauses/returns to setting mode
- BACK resets from a running/done state
- Audible Flipper notification when the timer reaches zero
- Native external FAP application structure
- No radio, NFC, Sub-GHz, or other hardware-control functions

## Build

Install the official micro Flipper Build Tool (uFBT), then from this directory run:

```bash
ufbt
```

The resulting `.fap` is placed in `dist/`.

To build and launch directly on a connected Flipper:

```bash
ufbt launch
```

For the latest official instructions, see the Flipper Developer documentation:
https://developer.flipper.net/flipperzero/doxygen/applications.html

## Controls

- Splash: wait ~1.2 seconds
- UP: increase by 1 second
- DOWN: decrease by 1 second
- OK: start / pause
- BACK: reset or exit

The maximum duration is hard-limited to 60 seconds.
