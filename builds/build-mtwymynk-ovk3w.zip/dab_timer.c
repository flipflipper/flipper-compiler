#include <furi.h>
#include <gui/gui.h>
#include <input/input.h>
#include <notification/notification.h>
#include <notification/notification_messages.h>

#define MAX_SECONDS 60
#define DEFAULT_SECONDS 30
#define SPLASH_MS 1200
#define FRAME_MS 100

typedef enum {
    DabTimerModeSplash,
    DabTimerModeSet,
    DabTimerModeRunning,
    DabTimerModeDone,
} DabTimerMode;

typedef struct {
    DabTimerMode mode;
    uint8_t set_seconds;
    uint8_t remaining;
    bool alarm_ack;
    uint32_t splash_started;
} DabTimerState;

static void draw_leaf(Canvas* canvas, int cx, int cy, int scale) {
    canvas_set_color(canvas, ColorBlack);

    // Stylized seven-lobed leaf.
    canvas_draw_disc(canvas, cx, cy, 3 * scale);
    canvas_draw_line(canvas, cx, cy + 2 * scale, cx, cy + 14 * scale);

    const int lobes[][2] = {
        {-1, -10}, {-6, -7}, {-10, -2},
        {1, -10}, {6, -7}, {10, -2}, {0, -5}
    };

    for(size_t i = 0; i < sizeof(lobes) / sizeof(lobes[0]); i++) {
        int x = cx + lobes[i][0] * scale;
        int y = cy + lobes[i][1] * scale;
        canvas_draw_disc(canvas, x, y, 3 * scale);
        canvas_draw_line(canvas, cx, cy, x, y);
    }
}

static void draw_centered_text(Canvas* canvas, const char* text, int y) {
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str_aligned(canvas, 64, y, AlignCenter, AlignBottom, text);
}

static void draw_timer(Canvas* canvas, const DabTimerState* state) {
    char time_text[8];
    uint8_t seconds = state->mode == DabTimerModeRunning
        ? state->remaining
        : state->set_seconds;

    snprintf(time_text, sizeof(time_text), "00:%02u", seconds);

    canvas_clear(canvas);
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str_aligned(canvas, 64, 12, AlignCenter, AlignBottom, "DAB TIMER");

    canvas_set_font(canvas, FontBigNumbers);
    canvas_draw_str_aligned(canvas, 64, 47, AlignCenter, AlignBottom, time_text);

    canvas_set_font(canvas, FontSecondary);

    if(state->mode == DabTimerModeSet) {
        canvas_draw_str_aligned(
            canvas, 64, 61, AlignCenter, AlignBottom,
            "UP/DOWN  SET    OK  START");
    } else if(state->mode == DabTimerModeRunning) {
        canvas_draw_str_aligned(
            canvas, 64, 61, AlignCenter, AlignBottom,
            "OK  PAUSE     BACK  RESET");
    } else if(state->mode == DabTimerModeDone) {
        canvas_draw_str_aligned(
            canvas, 64, 61, AlignCenter, AlignBottom,
            "DONE!   OK  RESET");
    } else {
        canvas_draw_str_aligned(
            canvas, 64, 61, AlignCenter, AlignBottom,
            "OK  START");
    }
}

static void draw_splash(Canvas* canvas) {
    canvas_clear(canvas);
    draw_leaf(canvas, 64, 29, 1);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str_aligned(canvas, 64, 57, AlignCenter, AlignBottom, "DAB TIMER");
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str_aligned(canvas, 64, 64, AlignCenter, AlignBottom, "V2");
}

static void input_callback(InputEvent* event, void* context) {
    FuriMessageQueue* q = context;
    furi_message_queue_put(q, event, 0);
}

static void draw_callback(Canvas* canvas, void* context) {
    DabTimerState* state = context;

    if(state->mode == DabTimerModeSplash) {
        draw_splash(canvas);
    } else {
        draw_timer(canvas, state);
    }
}

static void alarm(DabTimerState* state) {
    NotificationApp* notifications = furi_record_open(RECORD_NOTIFICATION);

    // Short audible notification sequence using the Flipper speaker.
    const NotificationSequence alarm_sequence = {
        &message_note_c5,
        &message_delay_100,
        &message_note_e5,
        &message_delay_100,
        &message_note_g5,
        &message_delay_100,
        &message_note_c5,
        &message_delay_100,
        &message_sound_off,
        NULL,
    };

    notification_message(notifications, &alarm_sequence);
    furi_record_close(RECORD_NOTIFICATION);
    state->alarm_ack = false;
}

int32_t dab_timer_app(void* p) {
    UNUSED(p);

    DabTimerState state = {
        .mode = DabTimerModeSplash,
        .set_seconds = DEFAULT_SECONDS,
        .remaining = DEFAULT_SECONDS,
        .alarm_ack = true,
        .splash_started = furi_get_tick(),
    };

    ViewPort* viewport = view_port_alloc();
    view_port_draw_callback_set(viewport, draw_callback, &state);

    FuriMessageQueue* queue = furi_message_queue_alloc(8, sizeof(InputEvent));

    view_port_input_callback_set(viewport, input_callback, queue);

    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, viewport, GuiLayerFullscreen);

    bool running = true;
    uint32_t last_second = furi_get_tick();

    while(running) {
        InputEvent event;
        FuriStatus status = furi_message_queue_get(queue, &event, FRAME_MS);

        if(state.mode == DabTimerModeSplash &&
           furi_get_tick() - state.splash_started >= SPLASH_MS) {
            state.mode = DabTimerModeSet;
            view_port_update(viewport);
        }

        if(state.mode == DabTimerModeRunning &&
           furi_get_tick() - last_second >= 1000) {
            last_second += 1000;

            if(state.remaining > 0) {
                state.remaining--;
                view_port_update(viewport);
            }

            if(state.remaining == 0 && state.alarm_ack) {
                state.mode = DabTimerModeDone;
                state.alarm_ack = false;
                alarm(&state);
                view_port_update(viewport);
            }
        }

        if(status != FuriStatusOk) {
            continue;
        }

        if(event.type != InputTypePress && event.type != InputTypeRepeat) {
            continue;
        }

        if(state.mode == DabTimerModeSplash) {
            continue;
        }

        if(event.key == InputKeyBack) {
            if(state.mode == DabTimerModeRunning || state.mode == DabTimerModeDone) {
                state.mode = DabTimerModeSet;
                state.remaining = state.set_seconds;
                state.alarm_ack = true;
                view_port_update(viewport);
            } else {
                running = false;
            }
            continue;
        }

        if(state.mode == DabTimerModeSet) {
            if(event.key == InputKeyUp) {
                if(state.set_seconds < MAX_SECONDS) state.set_seconds++;
                state.remaining = state.set_seconds;
                view_port_update(viewport);
            } else if(event.key == InputKeyDown) {
                if(state.set_seconds > 1) state.set_seconds--;
                state.remaining = state.set_seconds;
                view_port_update(viewport);
            } else if(event.key == InputKeyOk) {
                state.remaining = state.set_seconds;
                state.mode = DabTimerModeRunning;
                state.alarm_ack = true;
                last_second = furi_get_tick();
                view_port_update(viewport);
            }
        } else if(state.mode == DabTimerModeRunning) {
            if(event.key == InputKeyOk) {
                state.mode = DabTimerModeSet;
                state.set_seconds = state.remaining;
                view_port_update(viewport);
            }
        } else if(state.mode == DabTimerModeDone) {
            if(event.key == InputKeyOk) {
                state.remaining = state.set_seconds;
                state.mode = DabTimerModeSet;
                state.alarm_ack = true;
                view_port_update(viewport);
            }
        }
    }

    gui_remove_view_port(gui, viewport);
    furi_record_close(RECORD_GUI);

    furi_message_queue_free(queue);
    view_port_free(viewport);

    return 0;
}
