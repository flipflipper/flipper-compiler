// helpers/protopirate_storage.h
#pragma once

#include <furi.h>
#include <storage/storage.h>
#include <flipper_format/flipper_format.h>

#define PROTOPIRATE_APP_FOLDER       APP_DATA_PATH("saved")
#define PROTOPIRATE_APP_EXTENSION    ".psf"
#define PROTOPIRATE_APP_FILE_VERSION 1
#define PROTOPIRATE_TEMP_FILE        APP_DATA_PATH("saved/.temp.psf")
#define PROTOPIRATE_CACHE_FOLDER     APP_DATA_PATH("cache")
#define PROTOPIRATE_HISTORY_FOLDER   APP_DATA_PATH("cache/history")

// Initialize storage (create folder if needed)
bool protopirate_storage_init(void);

bool protopirate_storage_commit_temp_file(
    Storage* storage,
    const char* tmp_path,
    const char* final_path);

// Save a capture to a new file (auto-generated name)
bool protopirate_storage_save_capture(
    FlipperFormat* flipper_format,
    const char* protocol_name,
    FuriString* out_path);

// Save a capture to a specific file path (user-chosen name)
bool protopirate_storage_save_capture_to_path(FlipperFormat* flipper_format, const char* full_path);

// Delete temp file
void protopirate_storage_delete_temp(void);

// Get next available filename for a protocol
bool protopirate_storage_get_next_filename(const char* protocol_name, FuriString* out_filename);

bool protopirate_storage_get_capture_display_protocol(
    FlipperFormat* flipper_format,
    FuriString* protocol_name);

// Delete a file
bool protopirate_storage_delete_file(const char* file_path);

bool protopirate_storage_ensure_history_folder(void);

void protopirate_storage_purge_temp_history_at_startup(void);

void protopirate_storage_wipe_history_cache(void);

bool protopirate_storage_save_history_capture(
    FlipperFormat* flipper_format,
    uint32_t seq,
    FuriString* out_path);

void protopirate_storage_build_history_path(uint32_t seq, FuriString* out);
