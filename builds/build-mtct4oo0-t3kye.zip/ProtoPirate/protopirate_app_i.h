// protopirate_app_i.h
#pragma once

#include <stddef.h>
#include "helpers/protopirate_types.h"
#include "helpers/protopirate_settings.h"
#include "scenes/protopirate_scene.h"
#include "views/protopirate_receiver.h"
#include "protopirate_history.h"
#include "helpers/radio_device_loader.h"

#include <gui/gui.h>
#include <gui/view_dispatcher.h>
#include <gui/scene_manager.h>
#include <gui/modules/submenu.h>
#include <gui/modules/variable_item_list.h>
#include <gui/modules/widget.h>
#include <gui/modules/text_input.h>
#include <notification/notification_messages.h>
#include <lib/subghz/subghz_setting.h>
#include <lib/subghz/subghz_worker.h>
#include <lib/subghz/receiver.h>
#include <lib/subghz/transmitter.h>
#include <lib/subghz/devices/devices.h>
#include <lib/subghz/subghz_file_encoder_worker.h>
#include <lib/flipper_application/plugins/plugin_manager.h>
#include <lib/flipper_application/plugins/composite_resolver.h>
#include <dialogs/dialogs.h>
#include "defines.h"
#include "protocols/protocols_common.h"
#include "protocols/protocol_items.h"
#include "protocols/protopirate_protocol_plugins.h"
#ifdef ENABLE_EMULATE_FEATURE
#include "scenes/plugins/protopirate_emulate_plugin.h"
#endif
#include "scenes/plugins/protopirate_psa_bf_plugin.h"
#include "scenes/plugins/protopirate_tool_scene_plugin.h"
#include "helpers/protopirate_views.h"
#include "helpers/protopirate_radio.h"
#include "helpers/protopirate_protocol_plugin_host.h"
#include "helpers/protopirate_txrx.h"

#define PROTOPIRATE_KEYSTORE_DIR_NAME APP_ASSETS_PATH("encrypted")

typedef struct ProtoPirateApp ProtoPirateApp;

typedef struct ProtoPirateTxRx {
    SubGhzWorker* worker;
    SubGhzEnvironment* environment;
    SubGhzReceiver* receiver;
    SubGhzRadioPreset* preset;
    const SubGhzProtocolRegistry* protocol_registry;
    CompositeApiResolver* plugin_resolver;
    PluginManager* protocol_plugin_manager;
    const ProtoPirateProtocolPlugin* protocol_plugin;
    ProtoPirateProtocolRegistryRoute protocol_registry_route;
    ProtoPirateHistory* history;
    const SubGhzDevice* radio_device;
    ProtoPirateTxRxState txrx_state;
    ProtoPirateHopperState hopper_state;
    ProtoPirateRxKeyState rx_key_state;
    uint8_t hopper_idx_frequency;
    uint8_t hopper_timeout;
    uint16_t idx_menu_chosen;
} ProtoPirateTxRx;

struct ProtoPirateApp {
    Gui* gui;
    ViewDispatcher* view_dispatcher;
    SceneManager* scene_manager;
    NotificationApp* notifications;
    DialogsApp* dialogs;
    VariableItemList* variable_item_list;
    Submenu* submenu;
    Widget* widget;
    TextInput* text_input;
    View* view_about;
    FuriString* file_path;
    ProtoPirateReceiver* protopirate_receiver;
    ProtoPirateTxRx* txrx;
    SubGhzSetting* setting;
    ProtoPirateLock lock;
    FuriString* loaded_file_path;
    bool auto_save;
    bool check_saved;
    bool radio_initialized;
    uint32_t start_tx_time;
    uint8_t tx_power;
    char save_filename[64];
    FuriString* save_protocol;
    uint16_t save_history_idx;
    bool save_from_saved_info;
    bool emulate_disabled_for_loaded;
    bool emulate_feature_enabled;
#ifdef ENABLE_EMULATE_FEATURE
#define EMULATE_NAV_NONE     0U
#define EMULATE_NAV_POP      1U
#define EMULATE_NAV_STOP_APP 2U
    CompositeApiResolver* emulate_plugin_resolver;
    PluginManager* emulate_plugin_manager;
    const ProtoPirateEmulatePlugin* emulate_plugin;
    uint8_t emulate_nav_pending;
#endif
    CompositeApiResolver* psa_bf_plugin_resolver;
    PluginManager* psa_bf_plugin_manager;
    const ProtoPiratePsaBfPlugin* psa_bf_plugin;
    CompositeApiResolver* tool_scene_plugin_resolver;
    PluginManager* tool_scene_plugin_manager;
    const ProtoPirateToolScenePlugin* tool_scene_plugin;
    ProtoPirateToolScenePluginKind tool_scene_plugin_kind;

#define TOOL_SCENE_NAV_NONE            0U
#define TOOL_SCENE_NAV_POP             1U
#define TOOL_SCENE_NAV_NEXT            2U
#define TOOL_SCENE_NAV_SEARCH_PREVIOUS 3U
    uint8_t tool_scene_nav_pending;
    uint32_t tool_scene_nav_target;
};

#ifdef ENABLE_EMULATE_FEATURE
void protopirate_emulate_context_release(ProtoPirateApp* app);
#endif

typedef enum {
    ProtoPirateSetTypeFord_v0,
    ProtoPirateSetTypeMAX,
} ProtoPirateSetType;

bool protopirate_tool_scene_on_enter(void* app, ProtoPirateToolScenePluginKind kind);
bool protopirate_tool_scene_on_event(void* app, SceneManagerEvent event);
void protopirate_tool_scene_on_exit(void* app);
void protopirate_tool_scene_plugin_release(ProtoPirateApp* app);

void protopirate_app_free(ProtoPirateApp* app);

static const NotificationSequence sequence_tx = {
    &message_note_c5,
    &message_vibro_on,
    &message_red_255,
    &message_blue_255,
    &message_blink_start_10,
    &message_delay_25,
    &message_vibro_off,
    &message_delay_25,
    &message_sound_off,
    NULL,
};
